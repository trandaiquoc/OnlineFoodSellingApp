﻿namespace HQTCSDL
{
    partial class DOITAC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DOITAC));
            this.panelLEFT = new System.Windows.Forms.Panel();
            this.buttonDH = new System.Windows.Forms.Button();
            this.USER = new System.Windows.Forms.Button();
            this.buttonSP = new System.Windows.Forms.Button();
            this.buttonHD = new System.Windows.Forms.Button();
            this.buttonCH = new System.Windows.Forms.Button();
            this.buttonDX = new System.Windows.Forms.Button();
            this.THOAT = new System.Windows.Forms.Button();
            this.buttonTHD = new System.Windows.Forms.Button();
            this.buttonTK = new System.Windows.Forms.Button();
            this.AVATAR = new System.Windows.Forms.PictureBox();
            this.panel_body = new System.Windows.Forms.Panel();
            this.panelLEFT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLEFT
            // 
            this.panelLEFT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelLEFT.Controls.Add(this.buttonDH);
            this.panelLEFT.Controls.Add(this.USER);
            this.panelLEFT.Controls.Add(this.buttonSP);
            this.panelLEFT.Controls.Add(this.buttonHD);
            this.panelLEFT.Controls.Add(this.buttonCH);
            this.panelLEFT.Controls.Add(this.buttonDX);
            this.panelLEFT.Controls.Add(this.THOAT);
            this.panelLEFT.Controls.Add(this.buttonTHD);
            this.panelLEFT.Controls.Add(this.buttonTK);
            this.panelLEFT.Controls.Add(this.AVATAR);
            this.panelLEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLEFT.Location = new System.Drawing.Point(0, 0);
            this.panelLEFT.Name = "panelLEFT";
            this.panelLEFT.Size = new System.Drawing.Size(300, 1033);
            this.panelLEFT.TabIndex = 1;
            // 
            // buttonDH
            // 
            this.buttonDH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonDH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDH.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDH.FlatAppearance.BorderSize = 0;
            this.buttonDH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDH.ForeColor = System.Drawing.Color.White;
            this.buttonDH.Location = new System.Drawing.Point(0, 723);
            this.buttonDH.Name = "buttonDH";
            this.buttonDH.Size = new System.Drawing.Size(300, 75);
            this.buttonDH.TabIndex = 15;
            this.buttonDH.Text = "Đơn hàng";
            this.buttonDH.UseVisualStyleBackColor = false;
            this.buttonDH.Click += new System.EventHandler(this.buttonDH_Click);
            // 
            // USER
            // 
            this.USER.FlatAppearance.BorderSize = 0;
            this.USER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.USER.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.USER.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.USER.Location = new System.Drawing.Point(0, 300);
            this.USER.Name = "USER";
            this.USER.Size = new System.Drawing.Size(300, 50);
            this.USER.TabIndex = 12;
            this.USER.UseVisualStyleBackColor = true;
            // 
            // buttonSP
            // 
            this.buttonSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonSP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonSP.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonSP.FlatAppearance.BorderSize = 0;
            this.buttonSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSP.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonSP.ForeColor = System.Drawing.Color.White;
            this.buttonSP.Location = new System.Drawing.Point(0, 648);
            this.buttonSP.Name = "buttonSP";
            this.buttonSP.Size = new System.Drawing.Size(300, 75);
            this.buttonSP.TabIndex = 14;
            this.buttonSP.Text = "Sản phẩm";
            this.buttonSP.UseVisualStyleBackColor = false;
            this.buttonSP.Click += new System.EventHandler(this.buttonSP_Click);
            // 
            // buttonHD
            // 
            this.buttonHD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonHD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonHD.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonHD.FlatAppearance.BorderSize = 0;
            this.buttonHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonHD.ForeColor = System.Drawing.Color.White;
            this.buttonHD.Location = new System.Drawing.Point(0, 499);
            this.buttonHD.Name = "buttonHD";
            this.buttonHD.Size = new System.Drawing.Size(300, 75);
            this.buttonHD.TabIndex = 9;
            this.buttonHD.Text = "Hợp đồng đã lập";
            this.buttonHD.UseVisualStyleBackColor = false;
            this.buttonHD.Click += new System.EventHandler(this.buttonHD_Click);
            // 
            // buttonCH
            // 
            this.buttonCH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonCH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonCH.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonCH.FlatAppearance.BorderSize = 0;
            this.buttonCH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCH.ForeColor = System.Drawing.Color.White;
            this.buttonCH.Location = new System.Drawing.Point(0, 574);
            this.buttonCH.Name = "buttonCH";
            this.buttonCH.Size = new System.Drawing.Size(300, 75);
            this.buttonCH.TabIndex = 13;
            this.buttonCH.Text = "Cửa hàng";
            this.buttonCH.UseVisualStyleBackColor = false;
            this.buttonCH.Click += new System.EventHandler(this.buttonCH_Click);
            // 
            // buttonDX
            // 
            this.buttonDX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonDX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDX.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonDX.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDX.FlatAppearance.BorderSize = 0;
            this.buttonDX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDX.ForeColor = System.Drawing.Color.White;
            this.buttonDX.Location = new System.Drawing.Point(0, 883);
            this.buttonDX.Name = "buttonDX";
            this.buttonDX.Size = new System.Drawing.Size(300, 75);
            this.buttonDX.TabIndex = 11;
            this.buttonDX.Text = "Đăng Xuất";
            this.buttonDX.UseVisualStyleBackColor = false;
            this.buttonDX.Click += new System.EventHandler(this.buttonDX_Click);
            // 
            // THOAT
            // 
            this.THOAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.THOAT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.THOAT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.THOAT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.THOAT.FlatAppearance.BorderSize = 0;
            this.THOAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.THOAT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.THOAT.ForeColor = System.Drawing.Color.White;
            this.THOAT.Location = new System.Drawing.Point(0, 958);
            this.THOAT.Name = "THOAT";
            this.THOAT.Size = new System.Drawing.Size(300, 75);
            this.THOAT.TabIndex = 10;
            this.THOAT.Text = "Thoát";
            this.THOAT.UseVisualStyleBackColor = false;
            this.THOAT.Click += new System.EventHandler(this.THOAT_Click);
            // 
            // buttonTHD
            // 
            this.buttonTHD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTHD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonTHD.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTHD.FlatAppearance.BorderSize = 0;
            this.buttonTHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTHD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTHD.ForeColor = System.Drawing.Color.White;
            this.buttonTHD.Location = new System.Drawing.Point(0, 424);
            this.buttonTHD.Name = "buttonTHD";
            this.buttonTHD.Size = new System.Drawing.Size(300, 75);
            this.buttonTHD.TabIndex = 8;
            this.buttonTHD.Text = "Thêm hợp đồng";
            this.buttonTHD.UseVisualStyleBackColor = false;
            this.buttonTHD.Click += new System.EventHandler(this.buttonTHD_Click);
            // 
            // buttonTK
            // 
            this.buttonTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonTK.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTK.FlatAppearance.BorderSize = 0;
            this.buttonTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTK.ForeColor = System.Drawing.Color.White;
            this.buttonTK.Location = new System.Drawing.Point(0, 349);
            this.buttonTK.Name = "buttonTK";
            this.buttonTK.Size = new System.Drawing.Size(300, 75);
            this.buttonTK.TabIndex = 7;
            this.buttonTK.Text = "Tài Khoản";
            this.buttonTK.UseVisualStyleBackColor = false;
            this.buttonTK.Click += new System.EventHandler(this.buttonTK_Click);
            // 
            // AVATAR
            // 
            this.AVATAR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AVATAR.Image = ((System.Drawing.Image)(resources.GetObject("AVATAR.Image")));
            this.AVATAR.Location = new System.Drawing.Point(0, 0);
            this.AVATAR.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.AVATAR.Name = "AVATAR";
            this.AVATAR.Size = new System.Drawing.Size(300, 300);
            this.AVATAR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AVATAR.TabIndex = 4;
            this.AVATAR.TabStop = false;
            // 
            // panel_body
            // 
            this.panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_body.Location = new System.Drawing.Point(300, 0);
            this.panel_body.Name = "panel_body";
            this.panel_body.Size = new System.Drawing.Size(1602, 1033);
            this.panel_body.TabIndex = 2;
            // 
            // DOITAC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.panel_body);
            this.Controls.Add(this.panelLEFT);
            this.Name = "DOITAC";
            this.Text = "DOITAC";
            this.Load += new System.EventHandler(this.DOITAC_Load);
            this.panelLEFT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panelLEFT;
        private Button USER;
        private Button buttonDX;
        private Button THOAT;
        private Button buttonHD;
        private Button buttonTHD;
        private Button buttonTK;
        private PictureBox AVATAR;
        private Button buttonDH;
        private Button buttonSP;
        private Button buttonCH;
        private Panel panel_body;
    }
}