﻿namespace HQTCSDL
{
    partial class NHANVIEN_TK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cbbTDN = new System.Windows.Forms.ComboBox();
            this.cbbMK = new System.Windows.Forms.ComboBox();
            this.cbbXNMK = new System.Windows.Forms.ComboBox();
            this.cbbT = new System.Windows.Forms.ComboBox();
            this.cbbSDT = new System.Windows.Forms.ComboBox();
            this.cbbE = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 986);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1448, 114);
            this.label3.TabIndex = 2;
            this.label3.Text = "THÔNG TIN TÀI KHOẢN";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(58, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 33);
            this.label8.TabIndex = 3;
            this.label8.Text = "Tên đăng nhập";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(58, 365);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 33);
            this.label9.TabIndex = 4;
            this.label9.Text = "Mật khẩu";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(58, 515);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(241, 33);
            this.label10.TabIndex = 5;
            this.label10.Text = "Xác nhận mật khẩu";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(884, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 33);
            this.label11.TabIndex = 6;
            this.label11.Text = "Họ tên";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(884, 365);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 33);
            this.label5.TabIndex = 25;
            this.label5.Text = "Số điện thoại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(884, 509);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 33);
            this.label2.TabIndex = 28;
            this.label2.Text = "Email";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(58, 783);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(350, 75);
            this.button1.TabIndex = 31;
            this.button1.Text = "Lưu thông tin tài khoản";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(898, 783);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(350, 75);
            this.button2.TabIndex = 32;
            this.button2.Text = "Lưu thông tin chi tiết";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cbbTDN
            // 
            this.cbbTDN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDN.FormattingEnabled = true;
            this.cbbTDN.Location = new System.Drawing.Point(58, 258);
            this.cbbTDN.Name = "cbbTDN";
            this.cbbTDN.Size = new System.Drawing.Size(350, 40);
            this.cbbTDN.TabIndex = 49;
            // 
            // cbbMK
            // 
            this.cbbMK.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMK.FormattingEnabled = true;
            this.cbbMK.Location = new System.Drawing.Point(58, 412);
            this.cbbMK.Name = "cbbMK";
            this.cbbMK.Size = new System.Drawing.Size(350, 40);
            this.cbbMK.TabIndex = 50;
            // 
            // cbbXNMK
            // 
            this.cbbXNMK.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbXNMK.FormattingEnabled = true;
            this.cbbXNMK.Location = new System.Drawing.Point(58, 560);
            this.cbbXNMK.Name = "cbbXNMK";
            this.cbbXNMK.Size = new System.Drawing.Size(350, 40);
            this.cbbXNMK.TabIndex = 51;
            // 
            // cbbT
            // 
            this.cbbT.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbT.FormattingEnabled = true;
            this.cbbT.Location = new System.Drawing.Point(884, 258);
            this.cbbT.Name = "cbbT";
            this.cbbT.Size = new System.Drawing.Size(350, 40);
            this.cbbT.TabIndex = 52;
            // 
            // cbbSDT
            // 
            this.cbbSDT.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSDT.FormattingEnabled = true;
            this.cbbSDT.Location = new System.Drawing.Point(884, 412);
            this.cbbSDT.Name = "cbbSDT";
            this.cbbSDT.Size = new System.Drawing.Size(350, 40);
            this.cbbSDT.TabIndex = 53;
            // 
            // cbbE
            // 
            this.cbbE.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbE.FormattingEnabled = true;
            this.cbbE.Location = new System.Drawing.Point(884, 560);
            this.cbbE.Name = "cbbE";
            this.cbbE.Size = new System.Drawing.Size(350, 40);
            this.cbbE.TabIndex = 54;
            // 
            // NHANVIEN_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1452, 986);
            this.Controls.Add(this.cbbE);
            this.Controls.Add(this.cbbSDT);
            this.Controls.Add(this.cbbT);
            this.Controls.Add(this.cbbXNMK);
            this.Controls.Add(this.cbbMK);
            this.Controls.Add(this.cbbTDN);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "NHANVIEN_TK";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Label label3;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label5;
        private Label label2;
        private Button button1;
        private Button button2;
        private ComboBox cbbTDN;
        private ComboBox cbbMK;
        private ComboBox cbbXNMK;
        private ComboBox cbbT;
        private ComboBox cbbSDT;
        private ComboBox cbbE;
    }
}