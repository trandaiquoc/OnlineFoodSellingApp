﻿namespace HQTCSDL
{
    partial class DANGKY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DANGKY));
            this.exbutt = new System.Windows.Forms.Button();
            this.labelDK = new System.Windows.Forms.Label();
            this.AnMK = new System.Windows.Forms.PictureBox();
            this.hienMK = new System.Windows.Forms.PictureBox();
            this.tbMK = new System.Windows.Forms.TextBox();
            this.MATKHAU = new System.Windows.Forms.Label();
            this.tbTK = new System.Windows.Forms.TextBox();
            this.TENDANGNHAP = new System.Windows.Forms.Label();
            this.ANXNMK = new System.Windows.Forms.PictureBox();
            this.HIENXNMK = new System.Windows.Forms.PictureBox();
            this.tbXN = new System.Windows.Forms.TextBox();
            this.XACNHAN = new System.Windows.Forms.Label();
            this.DKbutton = new System.Windows.Forms.Button();
            this.cbDT = new System.Windows.Forms.CheckBox();
            this.cbKH = new System.Windows.Forms.CheckBox();
            this.cbTX = new System.Windows.Forms.CheckBox();
            this.DNbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.AnMK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hienMK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ANXNMK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HIENXNMK)).BeginInit();
            this.SuspendLayout();
            // 
            // exbutt
            // 
            this.exbutt.AutoSize = true;
            this.exbutt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.exbutt.FlatAppearance.BorderSize = 0;
            this.exbutt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exbutt.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.exbutt.ForeColor = System.Drawing.Color.White;
            this.exbutt.Location = new System.Drawing.Point(420, 793);
            this.exbutt.Name = "exbutt";
            this.exbutt.Size = new System.Drawing.Size(300, 50);
            this.exbutt.TabIndex = 21;
            this.exbutt.Text = "Thoát";
            this.exbutt.UseVisualStyleBackColor = false;
            this.exbutt.Click += new System.EventHandler(this.exbutt_Click);
            // 
            // labelDK
            // 
            this.labelDK.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelDK.Font = new System.Drawing.Font("Cambria", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelDK.Location = new System.Drawing.Point(0, 0);
            this.labelDK.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDK.Name = "labelDK";
            this.labelDK.Size = new System.Drawing.Size(732, 75);
            this.labelDK.TabIndex = 22;
            this.labelDK.Text = "Đăng Ký Tài Khoản";
            this.labelDK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AnMK
            // 
            this.AnMK.Image = ((System.Drawing.Image)(resources.GetObject("AnMK.Image")));
            this.AnMK.Location = new System.Drawing.Point(590, 352);
            this.AnMK.Name = "AnMK";
            this.AnMK.Size = new System.Drawing.Size(40, 40);
            this.AnMK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AnMK.TabIndex = 28;
            this.AnMK.TabStop = false;
            this.AnMK.Click += new System.EventHandler(this.AnMK_Click);
            // 
            // hienMK
            // 
            this.hienMK.Image = ((System.Drawing.Image)(resources.GetObject("hienMK.Image")));
            this.hienMK.Location = new System.Drawing.Point(590, 352);
            this.hienMK.Name = "hienMK";
            this.hienMK.Size = new System.Drawing.Size(40, 40);
            this.hienMK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hienMK.TabIndex = 27;
            this.hienMK.TabStop = false;
            this.hienMK.Click += new System.EventHandler(this.hienMK_Click);
            // 
            // tbMK
            // 
            this.tbMK.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbMK.Location = new System.Drawing.Point(124, 347);
            this.tbMK.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbMK.Multiline = true;
            this.tbMK.Name = "tbMK";
            this.tbMK.PasswordChar = '*';
            this.tbMK.Size = new System.Drawing.Size(511, 50);
            this.tbMK.TabIndex = 23;
            // 
            // MATKHAU
            // 
            this.MATKHAU.AutoSize = true;
            this.MATKHAU.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MATKHAU.Location = new System.Drawing.Point(119, 307);
            this.MATKHAU.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MATKHAU.Name = "MATKHAU";
            this.MATKHAU.Size = new System.Drawing.Size(104, 27);
            this.MATKHAU.TabIndex = 26;
            this.MATKHAU.Text = "Mật khẩu";
            // 
            // tbTK
            // 
            this.tbTK.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbTK.Location = new System.Drawing.Point(124, 193);
            this.tbTK.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbTK.Multiline = true;
            this.tbTK.Name = "tbTK";
            this.tbTK.Size = new System.Drawing.Size(511, 50);
            this.tbTK.TabIndex = 25;
            // 
            // TENDANGNHAP
            // 
            this.TENDANGNHAP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TENDANGNHAP.AutoSize = true;
            this.TENDANGNHAP.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TENDANGNHAP.Location = new System.Drawing.Point(119, 153);
            this.TENDANGNHAP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TENDANGNHAP.Name = "TENDANGNHAP";
            this.TENDANGNHAP.Size = new System.Drawing.Size(156, 27);
            this.TENDANGNHAP.TabIndex = 24;
            this.TENDANGNHAP.Text = "Tên đăng nhập";
            // 
            // ANXNMK
            // 
            this.ANXNMK.Image = ((System.Drawing.Image)(resources.GetObject("ANXNMK.Image")));
            this.ANXNMK.Location = new System.Drawing.Point(590, 480);
            this.ANXNMK.Name = "ANXNMK";
            this.ANXNMK.Size = new System.Drawing.Size(40, 40);
            this.ANXNMK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ANXNMK.TabIndex = 32;
            this.ANXNMK.TabStop = false;
            this.ANXNMK.Click += new System.EventHandler(this.ANXNMK_Click);
            // 
            // HIENXNMK
            // 
            this.HIENXNMK.Image = ((System.Drawing.Image)(resources.GetObject("HIENXNMK.Image")));
            this.HIENXNMK.Location = new System.Drawing.Point(590, 480);
            this.HIENXNMK.Name = "HIENXNMK";
            this.HIENXNMK.Size = new System.Drawing.Size(40, 40);
            this.HIENXNMK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.HIENXNMK.TabIndex = 31;
            this.HIENXNMK.TabStop = false;
            this.HIENXNMK.Click += new System.EventHandler(this.HIENXNMK_Click);
            // 
            // tbXN
            // 
            this.tbXN.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbXN.Location = new System.Drawing.Point(124, 475);
            this.tbXN.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbXN.Multiline = true;
            this.tbXN.Name = "tbXN";
            this.tbXN.PasswordChar = '*';
            this.tbXN.Size = new System.Drawing.Size(511, 50);
            this.tbXN.TabIndex = 29;
            // 
            // XACNHAN
            // 
            this.XACNHAN.AutoSize = true;
            this.XACNHAN.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.XACNHAN.Location = new System.Drawing.Point(119, 435);
            this.XACNHAN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.XACNHAN.Name = "XACNHAN";
            this.XACNHAN.Size = new System.Drawing.Size(198, 27);
            this.XACNHAN.TabIndex = 30;
            this.XACNHAN.Text = "Xác nhận mật khẩu";
            // 
            // DKbutton
            // 
            this.DKbutton.AutoSize = true;
            this.DKbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.DKbutton.FlatAppearance.BorderSize = 0;
            this.DKbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DKbutton.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DKbutton.ForeColor = System.Drawing.Color.White;
            this.DKbutton.Location = new System.Drawing.Point(201, 737);
            this.DKbutton.Name = "DKbutton";
            this.DKbutton.Size = new System.Drawing.Size(300, 50);
            this.DKbutton.TabIndex = 33;
            this.DKbutton.Text = "Đăng Ký";
            this.DKbutton.UseVisualStyleBackColor = false;
            this.DKbutton.Click += new System.EventHandler(this.DKbutton_Click);
            // 
            // cbDT
            // 
            this.cbDT.FlatAppearance.BorderSize = 0;
            this.cbDT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbDT.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbDT.Location = new System.Drawing.Point(119, 551);
            this.cbDT.Name = "cbDT";
            this.cbDT.Size = new System.Drawing.Size(300, 50);
            this.cbDT.TabIndex = 34;
            this.cbDT.Text = "Đối Tác";
            this.cbDT.UseVisualStyleBackColor = true;
            this.cbDT.CheckedChanged += new System.EventHandler(this.cbDT_CheckedChanged);
            // 
            // cbKH
            // 
            this.cbKH.FlatAppearance.BorderSize = 0;
            this.cbKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbKH.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbKH.Location = new System.Drawing.Point(119, 607);
            this.cbKH.Name = "cbKH";
            this.cbKH.Size = new System.Drawing.Size(300, 50);
            this.cbKH.TabIndex = 35;
            this.cbKH.Text = "Khách Hàng";
            this.cbKH.UseVisualStyleBackColor = true;
            this.cbKH.CheckedChanged += new System.EventHandler(this.cbKH_CheckedChanged);
            // 
            // cbTX
            // 
            this.cbTX.FlatAppearance.BorderSize = 0;
            this.cbTX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbTX.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbTX.Location = new System.Drawing.Point(119, 663);
            this.cbTX.Name = "cbTX";
            this.cbTX.Size = new System.Drawing.Size(300, 50);
            this.cbTX.TabIndex = 36;
            this.cbTX.Text = "Tài Xế";
            this.cbTX.UseVisualStyleBackColor = true;
            this.cbTX.CheckedChanged += new System.EventHandler(this.cbTX_CheckedChanged);
            // 
            // DNbutton
            // 
            this.DNbutton.AutoSize = true;
            this.DNbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.DNbutton.FlatAppearance.BorderSize = 0;
            this.DNbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DNbutton.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DNbutton.ForeColor = System.Drawing.Color.White;
            this.DNbutton.Location = new System.Drawing.Point(12, 793);
            this.DNbutton.Name = "DNbutton";
            this.DNbutton.Size = new System.Drawing.Size(300, 50);
            this.DNbutton.TabIndex = 37;
            this.DNbutton.Text = "Đăng Nhập";
            this.DNbutton.UseVisualStyleBackColor = false;
            this.DNbutton.Click += new System.EventHandler(this.DNbutton_Click);
            // 
            // DANGKY
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 1055);
            this.Controls.Add(this.DNbutton);
            this.Controls.Add(this.cbTX);
            this.Controls.Add(this.cbKH);
            this.Controls.Add(this.cbDT);
            this.Controls.Add(this.DKbutton);
            this.Controls.Add(this.ANXNMK);
            this.Controls.Add(this.HIENXNMK);
            this.Controls.Add(this.tbXN);
            this.Controls.Add(this.XACNHAN);
            this.Controls.Add(this.AnMK);
            this.Controls.Add(this.hienMK);
            this.Controls.Add(this.tbMK);
            this.Controls.Add(this.MATKHAU);
            this.Controls.Add(this.tbTK);
            this.Controls.Add(this.TENDANGNHAP);
            this.Controls.Add(this.labelDK);
            this.Controls.Add(this.exbutt);
            this.Name = "DANGKY";
            this.Text = "Đăng Ký Tài Khoản";
            ((System.ComponentModel.ISupportInitialize)(this.AnMK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hienMK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ANXNMK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HIENXNMK)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button exbutt;
        private Label labelDK;
        private PictureBox AnMK;
        private PictureBox hienMK;
        private TextBox tbMK;
        private Label MATKHAU;
        private TextBox tbTK;
        private Label TENDANGNHAP;
        private PictureBox ANXNMK;
        private PictureBox HIENXNMK;
        private TextBox tbXN;
        private Label XACNHAN;
        private Button DKbutton;
        private CheckBox cbDT;
        private CheckBox cbKH;
        private CheckBox cbTX;
        private Button DNbutton;
    }
}