﻿namespace HQTCSDL
{
    partial class TAIXE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TAIXE));
            this.panelLEFT = new System.Windows.Forms.Panel();
            this.USER = new System.Windows.Forms.Button();
            this.buttonDX = new System.Windows.Forms.Button();
            this.THOAT = new System.Windows.Forms.Button();
            this.buttonTN = new System.Windows.Forms.Button();
            this.buttonDH = new System.Windows.Forms.Button();
            this.buttonTK = new System.Windows.Forms.Button();
            this.AVATAR = new System.Windows.Forms.PictureBox();
            this.panel_body = new System.Windows.Forms.Panel();
            this.panelLEFT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLEFT
            // 
            this.panelLEFT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelLEFT.Controls.Add(this.USER);
            this.panelLEFT.Controls.Add(this.buttonDX);
            this.panelLEFT.Controls.Add(this.THOAT);
            this.panelLEFT.Controls.Add(this.buttonTN);
            this.panelLEFT.Controls.Add(this.buttonDH);
            this.panelLEFT.Controls.Add(this.buttonTK);
            this.panelLEFT.Controls.Add(this.AVATAR);
            this.panelLEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLEFT.Location = new System.Drawing.Point(0, 0);
            this.panelLEFT.Name = "panelLEFT";
            this.panelLEFT.Size = new System.Drawing.Size(300, 1033);
            this.panelLEFT.TabIndex = 0;
            // 
            // USER
            // 
            this.USER.FlatAppearance.BorderSize = 0;
            this.USER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.USER.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.USER.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.USER.Location = new System.Drawing.Point(0, 300);
            this.USER.Name = "USER";
            this.USER.Size = new System.Drawing.Size(300, 50);
            this.USER.TabIndex = 12;
            this.USER.UseVisualStyleBackColor = true;
            // 
            // buttonDX
            // 
            this.buttonDX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonDX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDX.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonDX.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDX.FlatAppearance.BorderSize = 0;
            this.buttonDX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDX.ForeColor = System.Drawing.Color.White;
            this.buttonDX.Location = new System.Drawing.Point(0, 833);
            this.buttonDX.Name = "buttonDX";
            this.buttonDX.Size = new System.Drawing.Size(300, 100);
            this.buttonDX.TabIndex = 11;
            this.buttonDX.Text = "Đăng Xuất";
            this.buttonDX.UseVisualStyleBackColor = false;
            this.buttonDX.Click += new System.EventHandler(this.buttonDX_Click);
            // 
            // THOAT
            // 
            this.THOAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.THOAT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.THOAT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.THOAT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.THOAT.FlatAppearance.BorderSize = 0;
            this.THOAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.THOAT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.THOAT.ForeColor = System.Drawing.Color.White;
            this.THOAT.Location = new System.Drawing.Point(0, 933);
            this.THOAT.Name = "THOAT";
            this.THOAT.Size = new System.Drawing.Size(300, 100);
            this.THOAT.TabIndex = 10;
            this.THOAT.Text = "Thoát";
            this.THOAT.UseVisualStyleBackColor = false;
            this.THOAT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // buttonTN
            // 
            this.buttonTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonTN.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTN.FlatAppearance.BorderSize = 0;
            this.buttonTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTN.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTN.ForeColor = System.Drawing.Color.White;
            this.buttonTN.Location = new System.Drawing.Point(0, 549);
            this.buttonTN.Name = "buttonTN";
            this.buttonTN.Size = new System.Drawing.Size(300, 100);
            this.buttonTN.TabIndex = 9;
            this.buttonTN.Text = "Thu Nhập";
            this.buttonTN.UseVisualStyleBackColor = false;
            this.buttonTN.Click += new System.EventHandler(this.buttonTN_Click);
            // 
            // buttonDH
            // 
            this.buttonDH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonDH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDH.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDH.FlatAppearance.BorderSize = 0;
            this.buttonDH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDH.ForeColor = System.Drawing.Color.White;
            this.buttonDH.Location = new System.Drawing.Point(0, 449);
            this.buttonDH.Name = "buttonDH";
            this.buttonDH.Size = new System.Drawing.Size(300, 100);
            this.buttonDH.TabIndex = 8;
            this.buttonDH.Text = "Đơn Hàng";
            this.buttonDH.UseVisualStyleBackColor = false;
            this.buttonDH.Click += new System.EventHandler(this.buttonDH_Click);
            // 
            // buttonTK
            // 
            this.buttonTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonTK.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTK.FlatAppearance.BorderSize = 0;
            this.buttonTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTK.ForeColor = System.Drawing.Color.White;
            this.buttonTK.Location = new System.Drawing.Point(0, 349);
            this.buttonTK.Name = "buttonTK";
            this.buttonTK.Size = new System.Drawing.Size(300, 100);
            this.buttonTK.TabIndex = 7;
            this.buttonTK.Text = "Tài Khoản";
            this.buttonTK.UseVisualStyleBackColor = false;
            this.buttonTK.Click += new System.EventHandler(this.buttonTK_Click);
            // 
            // AVATAR
            // 
            this.AVATAR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AVATAR.Image = ((System.Drawing.Image)(resources.GetObject("AVATAR.Image")));
            this.AVATAR.Location = new System.Drawing.Point(0, 0);
            this.AVATAR.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.AVATAR.Name = "AVATAR";
            this.AVATAR.Size = new System.Drawing.Size(300, 300);
            this.AVATAR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AVATAR.TabIndex = 4;
            this.AVATAR.TabStop = false;
            // 
            // panel_body
            // 
            this.panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_body.Location = new System.Drawing.Point(300, 0);
            this.panel_body.Name = "panel_body";
            this.panel_body.Size = new System.Drawing.Size(1602, 1033);
            this.panel_body.TabIndex = 0;
            // 
            // TAIXE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.panel_body);
            this.Controls.Add(this.panelLEFT);
            this.Name = "TAIXE";
            this.Text = "TAIXE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TAIXE_Load);
            this.panelLEFT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panelLEFT;
        private Panel panel_body;
        private PictureBox AVATAR;
        private Button buttonDX;
        private Button THOAT;
        private Button buttonTN;
        private Button buttonDH;
        private Button buttonTK;
        private Button USER;
    }
}