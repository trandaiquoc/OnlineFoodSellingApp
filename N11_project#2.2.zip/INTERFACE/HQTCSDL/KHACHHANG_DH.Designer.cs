﻿namespace HQTCSDL
{
    partial class KHACHHANG_DH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DANHSACHDONHANG = new System.Windows.Forms.Label();
            this.cbbE = new System.Windows.Forms.ComboBox();
            this.cbbSL = new System.Windows.Forms.ComboBox();
            this.cbbSDT = new System.Windows.Forms.ComboBox();
            this.cbbDC = new System.Windows.Forms.ComboBox();
            this.cbbL = new System.Windows.Forms.ComboBox();
            this.cbbT = new System.Windows.Forms.ComboBox();
            this.EMAIL = new System.Windows.Forms.Label();
            this.SDT = new System.Windows.Forms.Label();
            this.LOAIHANG = new System.Windows.Forms.Label();
            this.SLCUAHANG = new System.Windows.Forms.Label();
            this.DIACHI = new System.Windows.Forms.Label();
            this.TENQUAN = new System.Windows.Forms.Label();
            this.DATA = new System.Windows.Forms.DataGridView();
            this.buttonC = new System.Windows.Forms.Button();
            this.cbbMDT = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // DANHSACHDONHANG
            // 
            this.DANHSACHDONHANG.Dock = System.Windows.Forms.DockStyle.Top;
            this.DANHSACHDONHANG.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DANHSACHDONHANG.Location = new System.Drawing.Point(0, 0);
            this.DANHSACHDONHANG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DANHSACHDONHANG.Name = "DANHSACHDONHANG";
            this.DANHSACHDONHANG.Size = new System.Drawing.Size(1580, 95);
            this.DANHSACHDONHANG.TabIndex = 3;
            this.DANHSACHDONHANG.Text = "ĐẶT HÀNG";
            this.DANHSACHDONHANG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbbE
            // 
            this.cbbE.FormattingEnabled = true;
            this.cbbE.Location = new System.Drawing.Point(783, 412);
            this.cbbE.Margin = new System.Windows.Forms.Padding(4);
            this.cbbE.Name = "cbbE";
            this.cbbE.Size = new System.Drawing.Size(300, 28);
            this.cbbE.TabIndex = 61;
            // 
            // cbbSL
            // 
            this.cbbSL.FormattingEnabled = true;
            this.cbbSL.Location = new System.Drawing.Point(783, 296);
            this.cbbSL.Margin = new System.Windows.Forms.Padding(4);
            this.cbbSL.Name = "cbbSL";
            this.cbbSL.Size = new System.Drawing.Size(300, 28);
            this.cbbSL.TabIndex = 60;
            // 
            // cbbSDT
            // 
            this.cbbSDT.FormattingEnabled = true;
            this.cbbSDT.Location = new System.Drawing.Point(401, 412);
            this.cbbSDT.Margin = new System.Windows.Forms.Padding(4);
            this.cbbSDT.Name = "cbbSDT";
            this.cbbSDT.Size = new System.Drawing.Size(300, 28);
            this.cbbSDT.TabIndex = 59;
            // 
            // cbbDC
            // 
            this.cbbDC.FormattingEnabled = true;
            this.cbbDC.Location = new System.Drawing.Point(401, 296);
            this.cbbDC.Margin = new System.Windows.Forms.Padding(4);
            this.cbbDC.Name = "cbbDC";
            this.cbbDC.Size = new System.Drawing.Size(300, 28);
            this.cbbDC.TabIndex = 58;
            // 
            // cbbL
            // 
            this.cbbL.FormattingEnabled = true;
            this.cbbL.Location = new System.Drawing.Point(21, 412);
            this.cbbL.Margin = new System.Windows.Forms.Padding(4);
            this.cbbL.Name = "cbbL";
            this.cbbL.Size = new System.Drawing.Size(300, 28);
            this.cbbL.TabIndex = 57;
            // 
            // cbbT
            // 
            this.cbbT.FormattingEnabled = true;
            this.cbbT.Location = new System.Drawing.Point(21, 296);
            this.cbbT.Margin = new System.Windows.Forms.Padding(4);
            this.cbbT.Name = "cbbT";
            this.cbbT.Size = new System.Drawing.Size(300, 28);
            this.cbbT.TabIndex = 56;
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSize = true;
            this.EMAIL.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EMAIL.Location = new System.Drawing.Point(783, 378);
            this.EMAIL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(60, 23);
            this.EMAIL.TabIndex = 55;
            this.EMAIL.Text = "Email";
            // 
            // SDT
            // 
            this.SDT.AutoSize = true;
            this.SDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SDT.Location = new System.Drawing.Point(401, 378);
            this.SDT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SDT.Name = "SDT";
            this.SDT.Size = new System.Drawing.Size(129, 23);
            this.SDT.TabIndex = 54;
            this.SDT.Text = "Số Điện Thoại";
            // 
            // LOAIHANG
            // 
            this.LOAIHANG.AutoSize = true;
            this.LOAIHANG.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LOAIHANG.Location = new System.Drawing.Point(21, 378);
            this.LOAIHANG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LOAIHANG.Name = "LOAIHANG";
            this.LOAIHANG.Size = new System.Drawing.Size(122, 23);
            this.LOAIHANG.TabIndex = 53;
            this.LOAIHANG.Text = "Loại ẩm thực";
            // 
            // SLCUAHANG
            // 
            this.SLCUAHANG.AutoSize = true;
            this.SLCUAHANG.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SLCUAHANG.Location = new System.Drawing.Point(783, 262);
            this.SLCUAHANG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SLCUAHANG.Name = "SLCUAHANG";
            this.SLCUAHANG.Size = new System.Drawing.Size(166, 23);
            this.SLCUAHANG.TabIndex = 52;
            this.SLCUAHANG.Text = "Số lượng cửa hàng";
            // 
            // DIACHI
            // 
            this.DIACHI.AutoSize = true;
            this.DIACHI.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DIACHI.Location = new System.Drawing.Point(401, 262);
            this.DIACHI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DIACHI.Name = "DIACHI";
            this.DIACHI.Size = new System.Drawing.Size(69, 23);
            this.DIACHI.TabIndex = 51;
            this.DIACHI.Text = "Địa chỉ";
            // 
            // TENQUAN
            // 
            this.TENQUAN.AutoSize = true;
            this.TENQUAN.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TENQUAN.Location = new System.Drawing.Point(21, 262);
            this.TENQUAN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TENQUAN.Name = "TENQUAN";
            this.TENQUAN.Size = new System.Drawing.Size(90, 23);
            this.TENQUAN.TabIndex = 50;
            this.TENQUAN.Text = "Tên Quán";
            // 
            // DATA
            // 
            this.DATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.DATA.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DATA.Location = new System.Drawing.Point(0, 686);
            this.DATA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DATA.Name = "DATA";
            this.DATA.RowHeadersWidth = 51;
            this.DATA.RowTemplate.Height = 29;
            this.DATA.Size = new System.Drawing.Size(1580, 300);
            this.DATA.TabIndex = 62;
            this.DATA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_CellClick);
            // 
            // buttonC
            // 
            this.buttonC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonC.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonC.ForeColor = System.Drawing.Color.White;
            this.buttonC.Location = new System.Drawing.Point(1197, 309);
            this.buttonC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(129, 118);
            this.buttonC.TabIndex = 63;
            this.buttonC.Text = "Chọn";
            this.buttonC.UseVisualStyleBackColor = false;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // cbbMDT
            // 
            this.cbbMDT.FormattingEnabled = true;
            this.cbbMDT.Location = new System.Drawing.Point(1187, 433);
            this.cbbMDT.Name = "cbbMDT";
            this.cbbMDT.Size = new System.Drawing.Size(151, 28);
            this.cbbMDT.TabIndex = 64;
            // 
            // KHACHHANG_DH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1580, 986);
            this.Controls.Add(this.cbbMDT);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.DATA);
            this.Controls.Add(this.cbbE);
            this.Controls.Add(this.cbbSL);
            this.Controls.Add(this.cbbSDT);
            this.Controls.Add(this.cbbDC);
            this.Controls.Add(this.cbbL);
            this.Controls.Add(this.cbbT);
            this.Controls.Add(this.EMAIL);
            this.Controls.Add(this.SDT);
            this.Controls.Add(this.LOAIHANG);
            this.Controls.Add(this.SLCUAHANG);
            this.Controls.Add(this.DIACHI);
            this.Controls.Add(this.TENQUAN);
            this.Controls.Add(this.DANHSACHDONHANG);
            this.Name = "KHACHHANG_DH";
            this.Text = "KHACHHANG_DH";
            this.Load += new System.EventHandler(this.KHACHHANG_DH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label DANHSACHDONHANG;
        private ComboBox cbbE;
        private ComboBox cbbSL;
        private ComboBox cbbSDT;
        private ComboBox cbbDC;
        private ComboBox cbbL;
        private ComboBox cbbT;
        private Label EMAIL;
        private Label SDT;
        private Label LOAIHANG;
        private Label SLCUAHANG;
        private Label DIACHI;
        private Label TENQUAN;
        private DataGridView DATA;
        private Button buttonC;
        private ComboBox cbbMDT;
    }
}