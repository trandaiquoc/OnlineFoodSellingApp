﻿namespace HQTCSDL
{
    partial class KHACHHANG_QLDH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.MDH = new System.Windows.Forms.ComboBox();
            this.TTDH = new System.Windows.Forms.ComboBox();
            this.HTTT = new System.Windows.Forms.ComboBox();
            this.TT = new System.Windows.Forms.ComboBox();
            this.NM = new System.Windows.Forms.ComboBox();
            this.DATA = new System.Windows.Forms.DataGridView();
            this.buttonHD = new System.Windows.Forms.Button();
            this.buttonXMA = new System.Windows.Forms.Button();
            this.buttonXD = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 986);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1576, 78);
            this.label3.TabIndex = 2;
            this.label3.Text = "DANH SÁCH ĐƠN HÀNG";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(44, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 33);
            this.label8.TabIndex = 3;
            this.label8.Text = "Mã đơn hàng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(44, 297);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(240, 33);
            this.label9.TabIndex = 4;
            this.label9.Text = "Tình trạng đơn hàng";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(1080, 158);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(250, 33);
            this.label10.TabIndex = 5;
            this.label10.Text = "Hình thức thanh toán";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(597, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(126, 33);
            this.label13.TabIndex = 8;
            this.label13.Text = "Ngày mua";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(597, 297);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 33);
            this.label17.TabIndex = 21;
            this.label17.Text = "Tổng tiền";
            // 
            // MDH
            // 
            this.MDH.FormattingEnabled = true;
            this.MDH.Location = new System.Drawing.Point(45, 194);
            this.MDH.Name = "MDH";
            this.MDH.Size = new System.Drawing.Size(239, 28);
            this.MDH.TabIndex = 22;
            // 
            // TTDH
            // 
            this.TTDH.FormattingEnabled = true;
            this.TTDH.Location = new System.Drawing.Point(45, 333);
            this.TTDH.Name = "TTDH";
            this.TTDH.Size = new System.Drawing.Size(239, 28);
            this.TTDH.TabIndex = 23;
            // 
            // HTTT
            // 
            this.HTTT.FormattingEnabled = true;
            this.HTTT.Location = new System.Drawing.Point(1081, 194);
            this.HTTT.Name = "HTTT";
            this.HTTT.Size = new System.Drawing.Size(239, 28);
            this.HTTT.TabIndex = 24;
            // 
            // TT
            // 
            this.TT.FormattingEnabled = true;
            this.TT.Location = new System.Drawing.Point(597, 333);
            this.TT.Name = "TT";
            this.TT.Size = new System.Drawing.Size(239, 28);
            this.TT.TabIndex = 26;
            // 
            // NM
            // 
            this.NM.FormattingEnabled = true;
            this.NM.Location = new System.Drawing.Point(597, 194);
            this.NM.Name = "NM";
            this.NM.Size = new System.Drawing.Size(239, 28);
            this.NM.TabIndex = 29;
            // 
            // DATA
            // 
            this.DATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.DATA.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DATA.Location = new System.Drawing.Point(4, 788);
            this.DATA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DATA.Name = "DATA";
            this.DATA.RowHeadersWidth = 51;
            this.DATA.RowTemplate.Height = 29;
            this.DATA.Size = new System.Drawing.Size(1576, 198);
            this.DATA.TabIndex = 44;
            this.DATA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_CellClick);
            // 
            // buttonHD
            // 
            this.buttonHD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonHD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHD.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonHD.ForeColor = System.Drawing.Color.White;
            this.buttonHD.Location = new System.Drawing.Point(275, 473);
            this.buttonHD.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonHD.Name = "buttonHD";
            this.buttonHD.Size = new System.Drawing.Size(337, 71);
            this.buttonHD.TabIndex = 45;
            this.buttonHD.Text = "Huỷ đơn";
            this.buttonHD.UseVisualStyleBackColor = false;
            this.buttonHD.Click += new System.EventHandler(this.buttonHD_Click);
            // 
            // buttonXMA
            // 
            this.buttonXMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonXMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonXMA.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonXMA.ForeColor = System.Drawing.Color.White;
            this.buttonXMA.Location = new System.Drawing.Point(1081, 308);
            this.buttonXMA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonXMA.Name = "buttonXMA";
            this.buttonXMA.Size = new System.Drawing.Size(337, 71);
            this.buttonXMA.TabIndex = 46;
            this.buttonXMA.Text = "Xem món ăn trong đơn";
            this.buttonXMA.UseVisualStyleBackColor = false;
            this.buttonXMA.Click += new System.EventHandler(this.buttonXMA_Click);
            // 
            // buttonXD
            // 
            this.buttonXD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonXD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonXD.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonXD.ForeColor = System.Drawing.Color.White;
            this.buttonXD.Location = new System.Drawing.Point(832, 473);
            this.buttonXD.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonXD.Name = "buttonXD";
            this.buttonXD.Size = new System.Drawing.Size(337, 71);
            this.buttonXD.TabIndex = 47;
            this.buttonXD.Text = "Xoá Đơn";
            this.buttonXD.UseVisualStyleBackColor = false;
            this.buttonXD.Click += new System.EventHandler(this.buttonXD_Click);
            // 
            // KHACHHANG_QLDH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1580, 986);
            this.Controls.Add(this.buttonXD);
            this.Controls.Add(this.buttonXMA);
            this.Controls.Add(this.buttonHD);
            this.Controls.Add(this.DATA);
            this.Controls.Add(this.NM);
            this.Controls.Add(this.TT);
            this.Controls.Add(this.HTTT);
            this.Controls.Add(this.TTDH);
            this.Controls.Add(this.MDH);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "KHACHHANG_QLDH";
            this.Text = "QLDH";
            this.Load += new System.EventHandler(this.KHACHHANG_QLDH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Label label3;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label13;
        private Label label17;
        private ComboBox MDH;
        private ComboBox TTDH;
        private ComboBox HTTT;
        private ComboBox TT;
        private ComboBox NM;
        private DataGridView DATA;
        private Button buttonHD;
        private Button buttonXMA;
        private Button buttonXD;
    }
}