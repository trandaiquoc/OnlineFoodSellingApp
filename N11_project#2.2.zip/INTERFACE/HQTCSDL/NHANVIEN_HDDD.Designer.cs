﻿namespace HQTCSDL
{
    partial class NHANVIEN_HDDD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.DATA = new System.Windows.Forms.DataGridView();
            this.cbbMHD = new System.Windows.Forms.ComboBox();
            this.cbbTT = new System.Windows.Forms.ComboBox();
            this.cbbSTK = new System.Windows.Forms.ComboBox();
            this.cbbNH = new System.Windows.Forms.ComboBox();
            this.cbbCNNH = new System.Windows.Forms.ComboBox();
            this.cbbSL = new System.Windows.Forms.ComboBox();
            this.cbbNDD = new System.Windows.Forms.ComboBox();
            this.cbbPTHH = new System.Windows.Forms.ComboBox();
            this.cbbNKT = new System.Windows.Forms.ComboBox();
            this.cbbNBD = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonCN = new System.Windows.Forms.Button();
            this.cbbTDT = new System.Windows.Forms.ComboBox();
            this.cbbMST = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonTK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 986);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1448, 100);
            this.label3.TabIndex = 2;
            this.label3.Text = "HỢP ĐỒNG ĐÃ DUYỆT";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(38, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 23);
            this.label8.TabIndex = 3;
            this.label8.Text = "Mã hợp đồng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(407, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 23);
            this.label1.TabIndex = 26;
            this.label1.Text = "Số Tài Khoản của Đối tác";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(769, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 23);
            this.label2.TabIndex = 28;
            this.label2.Text = "Ngân Hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(1126, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(191, 23);
            this.label4.TabIndex = 30;
            this.label4.Text = "Chi nhánh Ngân hàng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(38, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 23);
            this.label6.TabIndex = 32;
            this.label6.Text = "Tình Trạng";
            this.label6.UseMnemonic = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(407, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(243, 23);
            this.label7.TabIndex = 34;
            this.label7.Text = "Số lượng chi nhánh đăng ký";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(769, 253);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 23);
            this.label9.TabIndex = 36;
            this.label9.Text = "Người đại diện";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(1126, 253);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 23);
            this.label10.TabIndex = 38;
            this.label10.Text = "Phần Trăm Hoa Hồng";
            // 
            // DATA
            // 
            this.DATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.DATA.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DATA.Location = new System.Drawing.Point(4, 650);
            this.DATA.Name = "DATA";
            this.DATA.RowHeadersWidth = 51;
            this.DATA.RowTemplate.Height = 29;
            this.DATA.Size = new System.Drawing.Size(1448, 336);
            this.DATA.TabIndex = 43;
            this.DATA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_CellClick);
            // 
            // cbbMHD
            // 
            this.cbbMHD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMHD.FormattingEnabled = true;
            this.cbbMHD.Location = new System.Drawing.Point(38, 166);
            this.cbbMHD.Name = "cbbMHD";
            this.cbbMHD.Size = new System.Drawing.Size(250, 31);
            this.cbbMHD.TabIndex = 44;
            // 
            // cbbTT
            // 
            this.cbbTT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTT.FormattingEnabled = true;
            this.cbbTT.Items.AddRange(new object[] {
            "Tái Ký"});
            this.cbbTT.Location = new System.Drawing.Point(38, 289);
            this.cbbTT.Name = "cbbTT";
            this.cbbTT.Size = new System.Drawing.Size(250, 31);
            this.cbbTT.TabIndex = 45;
            // 
            // cbbSTK
            // 
            this.cbbSTK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSTK.FormattingEnabled = true;
            this.cbbSTK.Location = new System.Drawing.Point(407, 166);
            this.cbbSTK.Name = "cbbSTK";
            this.cbbSTK.Size = new System.Drawing.Size(250, 31);
            this.cbbSTK.TabIndex = 46;
            // 
            // cbbNH
            // 
            this.cbbNH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNH.FormattingEnabled = true;
            this.cbbNH.Location = new System.Drawing.Point(769, 166);
            this.cbbNH.Name = "cbbNH";
            this.cbbNH.Size = new System.Drawing.Size(250, 31);
            this.cbbNH.TabIndex = 47;
            // 
            // cbbCNNH
            // 
            this.cbbCNNH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbCNNH.FormattingEnabled = true;
            this.cbbCNNH.Location = new System.Drawing.Point(1126, 166);
            this.cbbCNNH.Name = "cbbCNNH";
            this.cbbCNNH.Size = new System.Drawing.Size(250, 31);
            this.cbbCNNH.TabIndex = 48;
            // 
            // cbbSL
            // 
            this.cbbSL.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSL.FormattingEnabled = true;
            this.cbbSL.Location = new System.Drawing.Point(407, 289);
            this.cbbSL.Name = "cbbSL";
            this.cbbSL.Size = new System.Drawing.Size(250, 31);
            this.cbbSL.TabIndex = 49;
            // 
            // cbbNDD
            // 
            this.cbbNDD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNDD.FormattingEnabled = true;
            this.cbbNDD.Location = new System.Drawing.Point(769, 289);
            this.cbbNDD.Name = "cbbNDD";
            this.cbbNDD.Size = new System.Drawing.Size(250, 31);
            this.cbbNDD.TabIndex = 50;
            // 
            // cbbPTHH
            // 
            this.cbbPTHH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbPTHH.FormattingEnabled = true;
            this.cbbPTHH.Location = new System.Drawing.Point(1126, 289);
            this.cbbPTHH.Name = "cbbPTHH";
            this.cbbPTHH.Size = new System.Drawing.Size(250, 31);
            this.cbbPTHH.TabIndex = 51;
            // 
            // cbbNKT
            // 
            this.cbbNKT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNKT.FormattingEnabled = true;
            this.cbbNKT.Location = new System.Drawing.Point(407, 405);
            this.cbbNKT.Name = "cbbNKT";
            this.cbbNKT.Size = new System.Drawing.Size(250, 31);
            this.cbbNKT.TabIndex = 55;
            // 
            // cbbNBD
            // 
            this.cbbNBD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNBD.FormattingEnabled = true;
            this.cbbNBD.Location = new System.Drawing.Point(38, 405);
            this.cbbNBD.Name = "cbbNBD";
            this.cbbNBD.Size = new System.Drawing.Size(250, 31);
            this.cbbNBD.TabIndex = 54;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(407, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 23);
            this.label5.TabIndex = 53;
            this.label5.Text = "Ngày kết thúc";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(38, 369);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 23);
            this.label11.TabIndex = 52;
            this.label11.Text = "Ngày bắt đầu";
            // 
            // buttonCN
            // 
            this.buttonCN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCN.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCN.ForeColor = System.Drawing.Color.White;
            this.buttonCN.Location = new System.Drawing.Point(293, 523);
            this.buttonCN.Name = "buttonCN";
            this.buttonCN.Size = new System.Drawing.Size(300, 75);
            this.buttonCN.TabIndex = 40;
            this.buttonCN.Text = "Cập nhật";
            this.buttonCN.UseVisualStyleBackColor = false;
            this.buttonCN.Click += new System.EventHandler(this.buttonCN_Click);
            // 
            // cbbTDT
            // 
            this.cbbTDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDT.FormattingEnabled = true;
            this.cbbTDT.Location = new System.Drawing.Point(1126, 405);
            this.cbbTDT.Name = "cbbTDT";
            this.cbbTDT.Size = new System.Drawing.Size(250, 31);
            this.cbbTDT.TabIndex = 59;
            // 
            // cbbMST
            // 
            this.cbbMST.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMST.FormattingEnabled = true;
            this.cbbMST.Location = new System.Drawing.Point(769, 405);
            this.cbbMST.Name = "cbbMST";
            this.cbbMST.Size = new System.Drawing.Size(250, 31);
            this.cbbMST.TabIndex = 58;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(1126, 369);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 23);
            this.label12.TabIndex = 57;
            this.label12.Text = "Tên Đối Tác";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(769, 369);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 23);
            this.label13.TabIndex = 56;
            this.label13.Text = "Mã Số Thuế";
            // 
            // buttonTK
            // 
            this.buttonTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTK.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTK.ForeColor = System.Drawing.Color.White;
            this.buttonTK.Location = new System.Drawing.Point(819, 523);
            this.buttonTK.Name = "buttonTK";
            this.buttonTK.Size = new System.Drawing.Size(300, 75);
            this.buttonTK.TabIndex = 60;
            this.buttonTK.Text = "Tái ký";
            this.buttonTK.UseVisualStyleBackColor = false;
            this.buttonTK.Click += new System.EventHandler(this.buttonTK_Click);
            // 
            // NHANVIEN_HDDD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1452, 986);
            this.Controls.Add(this.buttonTK);
            this.Controls.Add(this.cbbTDT);
            this.Controls.Add(this.cbbMST);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cbbNKT);
            this.Controls.Add(this.cbbNBD);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbbPTHH);
            this.Controls.Add(this.cbbNDD);
            this.Controls.Add(this.cbbSL);
            this.Controls.Add(this.cbbCNNH);
            this.Controls.Add(this.cbbNH);
            this.Controls.Add(this.cbbSTK);
            this.Controls.Add(this.cbbTT);
            this.Controls.Add(this.cbbMHD);
            this.Controls.Add(this.DATA);
            this.Controls.Add(this.buttonCN);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "NHANVIEN_HDDD";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Label label3;
        private Label label8;
        private Label label1;
        private Label label2;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label9;
        private Label label10;
        private DataGridView DATA;
        private ComboBox cbbMHD;
        private ComboBox cbbTT;
        private ComboBox cbbSTK;
        private ComboBox cbbNH;
        private ComboBox cbbCNNH;
        private ComboBox cbbSL;
        private ComboBox cbbNDD;
        private ComboBox cbbPTHH;
        private ComboBox cbbNKT;
        private ComboBox cbbNBD;
        private Label label5;
        private Label label11;
        private Button buttonCN;
        private ComboBox cbbTDT;
        private ComboBox cbbMST;
        private Label label12;
        private Label label13;
        private Button buttonTK;
    }
}