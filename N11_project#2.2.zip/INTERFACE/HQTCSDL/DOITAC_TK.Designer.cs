﻿namespace HQTCSDL
{
    partial class DOITAC_TK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TTTK = new System.Windows.Forms.Label();
            this.luuttct = new System.Windows.Forms.Button();
            this.Luutttk = new System.Windows.Forms.Button();
            this.cbbXNMK = new System.Windows.Forms.ComboBox();
            this.cbbMK = new System.Windows.Forms.ComboBox();
            this.cbbTDN = new System.Windows.Forms.ComboBox();
            this.XACNHANMATKHAU = new System.Windows.Forms.Label();
            this.MATKHAU = new System.Windows.Forms.Label();
            this.TENDANGNHAP = new System.Windows.Forms.Label();
            this.cbbDSB = new System.Windows.Forms.ComboBox();
            this.cbbMST = new System.Windows.Forms.ComboBox();
            this.cbbLAT = new System.Windows.Forms.ComboBox();
            this.cbbSLD = new System.Windows.Forms.ComboBox();
            this.cbbSLCH = new System.Windows.Forms.ComboBox();
            this.cbbE = new System.Windows.Forms.ComboBox();
            this.cbbSDT = new System.Windows.Forms.ComboBox();
            this.cbbDC = new System.Windows.Forms.ComboBox();
            this.cbbNDD = new System.Windows.Forms.ComboBox();
            this.cbbTQ = new System.Windows.Forms.ComboBox();
            this.CHINHANHNGANHANG = new System.Windows.Forms.Label();
            this.EMAIL = new System.Windows.Forms.Label();
            this.NGANHANG = new System.Windows.Forms.Label();
            this.SDT = new System.Windows.Forms.Label();
            this.lat = new System.Windows.Forms.Label();
            this.CMND = new System.Windows.Forms.Label();
            this.DIACHI = new System.Windows.Forms.Label();
            this.BIENSOXE = new System.Windows.Forms.Label();
            this.KHUVUC = new System.Windows.Forms.Label();
            this.HOTEN = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TTTK
            // 
            this.TTTK.Dock = System.Windows.Forms.DockStyle.Top;
            this.TTTK.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TTTK.Location = new System.Drawing.Point(0, 0);
            this.TTTK.Name = "TTTK";
            this.TTTK.Size = new System.Drawing.Size(1532, 114);
            this.TTTK.TabIndex = 3;
            this.TTTK.Text = "THÔNG TIN TÀI KHOẢN";
            this.TTTK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // luuttct
            // 
            this.luuttct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.luuttct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.luuttct.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.luuttct.ForeColor = System.Drawing.Color.White;
            this.luuttct.Location = new System.Drawing.Point(866, 838);
            this.luuttct.Name = "luuttct";
            this.luuttct.Size = new System.Drawing.Size(350, 75);
            this.luuttct.TabIndex = 34;
            this.luuttct.Text = "Lưu thông tin chi tiết";
            this.luuttct.UseVisualStyleBackColor = false;
            this.luuttct.Click += new System.EventHandler(this.luuttct_Click);
            // 
            // Luutttk
            // 
            this.Luutttk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.Luutttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Luutttk.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Luutttk.ForeColor = System.Drawing.Color.White;
            this.Luutttk.Location = new System.Drawing.Point(110, 838);
            this.Luutttk.Name = "Luutttk";
            this.Luutttk.Size = new System.Drawing.Size(350, 75);
            this.Luutttk.TabIndex = 33;
            this.Luutttk.Text = "Lưu thông tin tài khoản";
            this.Luutttk.UseVisualStyleBackColor = false;
            this.Luutttk.Click += new System.EventHandler(this.Luutttk_Click);
            // 
            // cbbXNMK
            // 
            this.cbbXNMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbXNMK.FormattingEnabled = true;
            this.cbbXNMK.Location = new System.Drawing.Point(144, 569);
            this.cbbXNMK.Name = "cbbXNMK";
            this.cbbXNMK.Size = new System.Drawing.Size(300, 31);
            this.cbbXNMK.TabIndex = 53;
            // 
            // cbbMK
            // 
            this.cbbMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMK.FormattingEnabled = true;
            this.cbbMK.Location = new System.Drawing.Point(144, 392);
            this.cbbMK.Name = "cbbMK";
            this.cbbMK.Size = new System.Drawing.Size(300, 31);
            this.cbbMK.TabIndex = 52;
            // 
            // cbbTDN
            // 
            this.cbbTDN.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDN.FormattingEnabled = true;
            this.cbbTDN.Location = new System.Drawing.Point(144, 255);
            this.cbbTDN.Name = "cbbTDN";
            this.cbbTDN.Size = new System.Drawing.Size(300, 31);
            this.cbbTDN.TabIndex = 51;
            // 
            // XACNHANMATKHAU
            // 
            this.XACNHANMATKHAU.AutoSize = true;
            this.XACNHANMATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.XACNHANMATKHAU.Location = new System.Drawing.Point(144, 498);
            this.XACNHANMATKHAU.Name = "XACNHANMATKHAU";
            this.XACNHANMATKHAU.Size = new System.Drawing.Size(241, 33);
            this.XACNHANMATKHAU.TabIndex = 50;
            this.XACNHANMATKHAU.Text = "Xác nhận mật khẩu";
            // 
            // MATKHAU
            // 
            this.MATKHAU.AutoSize = true;
            this.MATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MATKHAU.Location = new System.Drawing.Point(144, 348);
            this.MATKHAU.Name = "MATKHAU";
            this.MATKHAU.Size = new System.Drawing.Size(126, 33);
            this.MATKHAU.TabIndex = 49;
            this.MATKHAU.Text = "Mật khẩu";
            // 
            // TENDANGNHAP
            // 
            this.TENDANGNHAP.AutoSize = true;
            this.TENDANGNHAP.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TENDANGNHAP.Location = new System.Drawing.Point(144, 202);
            this.TENDANGNHAP.Name = "TENDANGNHAP";
            this.TENDANGNHAP.Size = new System.Drawing.Size(193, 33);
            this.TENDANGNHAP.TabIndex = 48;
            this.TENDANGNHAP.Text = "Tên đăng nhập";
            // 
            // cbbDSB
            // 
            this.cbbDSB.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbDSB.FormattingEnabled = true;
            this.cbbDSB.Location = new System.Drawing.Point(1085, 753);
            this.cbbDSB.Name = "cbbDSB";
            this.cbbDSB.Size = new System.Drawing.Size(300, 31);
            this.cbbDSB.TabIndex = 77;
            // 
            // cbbMST
            // 
            this.cbbMST.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMST.FormattingEnabled = true;
            this.cbbMST.Location = new System.Drawing.Point(1085, 611);
            this.cbbMST.Name = "cbbMST";
            this.cbbMST.Size = new System.Drawing.Size(300, 31);
            this.cbbMST.TabIndex = 76;
            // 
            // cbbLAT
            // 
            this.cbbLAT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbLAT.FormattingEnabled = true;
            this.cbbLAT.Location = new System.Drawing.Point(1085, 464);
            this.cbbLAT.Name = "cbbLAT";
            this.cbbLAT.Size = new System.Drawing.Size(300, 31);
            this.cbbLAT.TabIndex = 75;
            // 
            // cbbSLD
            // 
            this.cbbSLD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSLD.FormattingEnabled = true;
            this.cbbSLD.Location = new System.Drawing.Point(1085, 331);
            this.cbbSLD.Name = "cbbSLD";
            this.cbbSLD.Size = new System.Drawing.Size(300, 31);
            this.cbbSLD.TabIndex = 74;
            // 
            // cbbSLCH
            // 
            this.cbbSLCH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSLCH.FormattingEnabled = true;
            this.cbbSLCH.Location = new System.Drawing.Point(1085, 196);
            this.cbbSLCH.Name = "cbbSLCH";
            this.cbbSLCH.Size = new System.Drawing.Size(300, 31);
            this.cbbSLCH.TabIndex = 73;
            // 
            // cbbE
            // 
            this.cbbE.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbE.FormattingEnabled = true;
            this.cbbE.Location = new System.Drawing.Point(670, 753);
            this.cbbE.Name = "cbbE";
            this.cbbE.Size = new System.Drawing.Size(300, 31);
            this.cbbE.TabIndex = 72;
            // 
            // cbbSDT
            // 
            this.cbbSDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSDT.FormattingEnabled = true;
            this.cbbSDT.Location = new System.Drawing.Point(670, 614);
            this.cbbSDT.Name = "cbbSDT";
            this.cbbSDT.Size = new System.Drawing.Size(300, 31);
            this.cbbSDT.TabIndex = 71;
            // 
            // cbbDC
            // 
            this.cbbDC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbDC.FormattingEnabled = true;
            this.cbbDC.Location = new System.Drawing.Point(670, 464);
            this.cbbDC.Name = "cbbDC";
            this.cbbDC.Size = new System.Drawing.Size(300, 31);
            this.cbbDC.TabIndex = 70;
            // 
            // cbbNDD
            // 
            this.cbbNDD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNDD.FormattingEnabled = true;
            this.cbbNDD.Location = new System.Drawing.Point(670, 331);
            this.cbbNDD.Name = "cbbNDD";
            this.cbbNDD.Size = new System.Drawing.Size(300, 31);
            this.cbbNDD.TabIndex = 69;
            // 
            // cbbTQ
            // 
            this.cbbTQ.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTQ.FormattingEnabled = true;
            this.cbbTQ.Location = new System.Drawing.Point(670, 196);
            this.cbbTQ.Name = "cbbTQ";
            this.cbbTQ.Size = new System.Drawing.Size(300, 31);
            this.cbbTQ.TabIndex = 68;
            // 
            // CHINHANHNGANHANG
            // 
            this.CHINHANHNGANHANG.AutoSize = true;
            this.CHINHANHNGANHANG.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CHINHANHNGANHANG.Location = new System.Drawing.Point(1085, 691);
            this.CHINHANHNGANHANG.Name = "CHINHANHNGANHANG";
            this.CHINHANHNGANHANG.Size = new System.Drawing.Size(182, 33);
            this.CHINHANHNGANHANG.TabIndex = 66;
            this.CHINHANHNGANHANG.Text = "Doanh Số Bán";
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSize = true;
            this.EMAIL.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EMAIL.Location = new System.Drawing.Point(670, 691);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(84, 33);
            this.EMAIL.TabIndex = 67;
            this.EMAIL.Text = "Email";
            // 
            // NGANHANG
            // 
            this.NGANHANG.AutoSize = true;
            this.NGANHANG.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NGANHANG.Location = new System.Drawing.Point(1085, 551);
            this.NGANHANG.Name = "NGANHANG";
            this.NGANHANG.Size = new System.Drawing.Size(154, 33);
            this.NGANHANG.TabIndex = 65;
            this.NGANHANG.Text = "Mã Số Thuế";
            // 
            // SDT
            // 
            this.SDT.AutoSize = true;
            this.SDT.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SDT.Location = new System.Drawing.Point(670, 551);
            this.SDT.Name = "SDT";
            this.SDT.Size = new System.Drawing.Size(171, 33);
            this.SDT.TabIndex = 64;
            this.SDT.Text = "Số điện thoại";
            // 
            // lat
            // 
            this.lat.AutoSize = true;
            this.lat.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lat.Location = new System.Drawing.Point(1085, 401);
            this.lat.Name = "lat";
            this.lat.Size = new System.Drawing.Size(180, 33);
            this.lat.TabIndex = 63;
            this.lat.Text = "Loại Ẩm Thực";
            // 
            // CMND
            // 
            this.CMND.AutoSize = true;
            this.CMND.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CMND.Location = new System.Drawing.Point(670, 268);
            this.CMND.Name = "CMND";
            this.CMND.Size = new System.Drawing.Size(200, 33);
            this.CMND.TabIndex = 61;
            this.CMND.Text = "Người Đại Diện";
            // 
            // DIACHI
            // 
            this.DIACHI.AutoSize = true;
            this.DIACHI.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DIACHI.Location = new System.Drawing.Point(670, 401);
            this.DIACHI.Name = "DIACHI";
            this.DIACHI.Size = new System.Drawing.Size(97, 33);
            this.DIACHI.TabIndex = 62;
            this.DIACHI.Text = "Địa chỉ";
            // 
            // BIENSOXE
            // 
            this.BIENSOXE.AutoSize = true;
            this.BIENSOXE.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BIENSOXE.Location = new System.Drawing.Point(1085, 141);
            this.BIENSOXE.Name = "BIENSOXE";
            this.BIENSOXE.Size = new System.Drawing.Size(251, 33);
            this.BIENSOXE.TabIndex = 60;
            this.BIENSOXE.Text = "Số Lượng Cửa Hàng";
            // 
            // KHUVUC
            // 
            this.KHUVUC.AutoSize = true;
            this.KHUVUC.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.KHUVUC.Location = new System.Drawing.Point(1085, 268);
            this.KHUVUC.Name = "KHUVUC";
            this.KHUVUC.Size = new System.Drawing.Size(292, 33);
            this.KHUVUC.TabIndex = 59;
            this.KHUVUC.Text = "Số lượng đơn mỗi ngày";
            // 
            // HOTEN
            // 
            this.HOTEN.AutoSize = true;
            this.HOTEN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HOTEN.Location = new System.Drawing.Point(670, 141);
            this.HOTEN.Name = "HOTEN";
            this.HOTEN.Size = new System.Drawing.Size(129, 33);
            this.HOTEN.TabIndex = 58;
            this.HOTEN.Text = "Tên Quán";
            // 
            // DOITAC_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1532, 986);
            this.Controls.Add(this.cbbDSB);
            this.Controls.Add(this.cbbMST);
            this.Controls.Add(this.cbbLAT);
            this.Controls.Add(this.cbbSLD);
            this.Controls.Add(this.cbbSLCH);
            this.Controls.Add(this.cbbE);
            this.Controls.Add(this.cbbSDT);
            this.Controls.Add(this.cbbDC);
            this.Controls.Add(this.cbbNDD);
            this.Controls.Add(this.cbbTQ);
            this.Controls.Add(this.CHINHANHNGANHANG);
            this.Controls.Add(this.EMAIL);
            this.Controls.Add(this.NGANHANG);
            this.Controls.Add(this.SDT);
            this.Controls.Add(this.lat);
            this.Controls.Add(this.CMND);
            this.Controls.Add(this.DIACHI);
            this.Controls.Add(this.BIENSOXE);
            this.Controls.Add(this.KHUVUC);
            this.Controls.Add(this.HOTEN);
            this.Controls.Add(this.cbbXNMK);
            this.Controls.Add(this.cbbMK);
            this.Controls.Add(this.cbbTDN);
            this.Controls.Add(this.XACNHANMATKHAU);
            this.Controls.Add(this.MATKHAU);
            this.Controls.Add(this.TENDANGNHAP);
            this.Controls.Add(this.luuttct);
            this.Controls.Add(this.Luutttk);
            this.Controls.Add(this.TTTK);
            this.Name = "DOITAC_TK";
            this.Text = "TÀI KHOẢN";
            this.Load += new System.EventHandler(this.DOITAC_TK_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label TTTK;
        private Button luuttct;
        private Button Luutttk;
        private ComboBox cbbXNMK;
        private ComboBox cbbMK;
        private ComboBox cbbTDN;
        private Label XACNHANMATKHAU;
        private Label MATKHAU;
        private Label TENDANGNHAP;
        private ComboBox cbbDSB;
        private ComboBox cbbMST;
        private ComboBox cbbLAT;
        private ComboBox cbbSLD;
        private ComboBox cbbSLCH;
        private ComboBox cbbE;
        private ComboBox cbbSDT;
        private ComboBox cbbDC;
        private ComboBox cbbNDD;
        private ComboBox cbbTQ;
        private Label CHINHANHNGANHANG;
        private Label EMAIL;
        private Label NGANHANG;
        private Label SDT;
        private Label lat;
        private Label CMND;
        private Label DIACHI;
        private Label BIENSOXE;
        private Label KHUVUC;
        private Label HOTEN;
    }
}