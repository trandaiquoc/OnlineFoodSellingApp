﻿namespace HQTCSDL
{
    partial class TAIXE_TK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.TTTK = new System.Windows.Forms.Label();
            this.TENDANGNHAP = new System.Windows.Forms.Label();
            this.MATKHAU = new System.Windows.Forms.Label();
            this.XACNHANMATKHAU = new System.Windows.Forms.Label();
            this.KHUVUC = new System.Windows.Forms.Label();
            this.BIENSOXE = new System.Windows.Forms.Label();
            this.HOTEN = new System.Windows.Forms.Label();
            this.CMND = new System.Windows.Forms.Label();
            this.SDT = new System.Windows.Forms.Label();
            this.DIACHI = new System.Windows.Forms.Label();
            this.NGANHANG = new System.Windows.Forms.Label();
            this.SOTAIKHOAN = new System.Windows.Forms.Label();
            this.CHINHANHNGANHANG = new System.Windows.Forms.Label();
            this.EMAIL = new System.Windows.Forms.Label();
            this.Luutttk = new System.Windows.Forms.Button();
            this.luuttct = new System.Windows.Forms.Button();
            this.cbbTDN = new System.Windows.Forms.ComboBox();
            this.cbbMK = new System.Windows.Forms.ComboBox();
            this.cbbXNMK = new System.Windows.Forms.ComboBox();
            this.cbbHT = new System.Windows.Forms.ComboBox();
            this.cbbCMND = new System.Windows.Forms.ComboBox();
            this.cbbDC = new System.Windows.Forms.ComboBox();
            this.cbbSDT = new System.Windows.Forms.ComboBox();
            this.cbbE = new System.Windows.Forms.ComboBox();
            this.cbbBSX = new System.Windows.Forms.ComboBox();
            this.cbbKVHD = new System.Windows.Forms.ComboBox();
            this.cbbSTK = new System.Windows.Forms.ComboBox();
            this.cbbNH = new System.Windows.Forms.ComboBox();
            this.cbbCNNH = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 986);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // TTTK
            // 
            this.TTTK.Dock = System.Windows.Forms.DockStyle.Top;
            this.TTTK.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TTTK.Location = new System.Drawing.Point(4, 0);
            this.TTTK.Name = "TTTK";
            this.TTTK.Size = new System.Drawing.Size(1580, 114);
            this.TTTK.TabIndex = 2;
            this.TTTK.Text = "THÔNG TIN TÀI KHOẢN";
            this.TTTK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TENDANGNHAP
            // 
            this.TENDANGNHAP.AutoSize = true;
            this.TENDANGNHAP.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TENDANGNHAP.Location = new System.Drawing.Point(93, 230);
            this.TENDANGNHAP.Name = "TENDANGNHAP";
            this.TENDANGNHAP.Size = new System.Drawing.Size(193, 33);
            this.TENDANGNHAP.TabIndex = 3;
            this.TENDANGNHAP.Text = "Tên đăng nhập";
            // 
            // MATKHAU
            // 
            this.MATKHAU.AutoSize = true;
            this.MATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MATKHAU.Location = new System.Drawing.Point(93, 376);
            this.MATKHAU.Name = "MATKHAU";
            this.MATKHAU.Size = new System.Drawing.Size(126, 33);
            this.MATKHAU.TabIndex = 4;
            this.MATKHAU.Text = "Mật khẩu";
            // 
            // XACNHANMATKHAU
            // 
            this.XACNHANMATKHAU.AutoSize = true;
            this.XACNHANMATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.XACNHANMATKHAU.Location = new System.Drawing.Point(93, 526);
            this.XACNHANMATKHAU.Name = "XACNHANMATKHAU";
            this.XACNHANMATKHAU.Size = new System.Drawing.Size(241, 33);
            this.XACNHANMATKHAU.TabIndex = 5;
            this.XACNHANMATKHAU.Text = "Xác nhận mật khẩu";
            // 
            // KHUVUC
            // 
            this.KHUVUC.AutoSize = true;
            this.KHUVUC.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.KHUVUC.Location = new System.Drawing.Point(1072, 283);
            this.KHUVUC.Name = "KHUVUC";
            this.KHUVUC.Size = new System.Drawing.Size(238, 33);
            this.KHUVUC.TabIndex = 7;
            this.KHUVUC.Text = "Khu vực hoạt động";
            // 
            // BIENSOXE
            // 
            this.BIENSOXE.AutoSize = true;
            this.BIENSOXE.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BIENSOXE.Location = new System.Drawing.Point(1072, 156);
            this.BIENSOXE.Name = "BIENSOXE";
            this.BIENSOXE.Size = new System.Drawing.Size(136, 33);
            this.BIENSOXE.TabIndex = 8;
            this.BIENSOXE.Text = "Biển số xe";
            // 
            // HOTEN
            // 
            this.HOTEN.AutoSize = true;
            this.HOTEN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.HOTEN.Location = new System.Drawing.Point(657, 156);
            this.HOTEN.Name = "HOTEN";
            this.HOTEN.Size = new System.Drawing.Size(94, 33);
            this.HOTEN.TabIndex = 6;
            this.HOTEN.Text = "Họ tên";
            // 
            // CMND
            // 
            this.CMND.AutoSize = true;
            this.CMND.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CMND.Location = new System.Drawing.Point(657, 283);
            this.CMND.Name = "CMND";
            this.CMND.Size = new System.Drawing.Size(280, 33);
            this.CMND.TabIndex = 21;
            this.CMND.Text = "Chứng minh nhân dân";
            // 
            // SDT
            // 
            this.SDT.AutoSize = true;
            this.SDT.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SDT.Location = new System.Drawing.Point(657, 566);
            this.SDT.Name = "SDT";
            this.SDT.Size = new System.Drawing.Size(171, 33);
            this.SDT.TabIndex = 25;
            this.SDT.Text = "Số điện thoại";
            // 
            // DIACHI
            // 
            this.DIACHI.AutoSize = true;
            this.DIACHI.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DIACHI.Location = new System.Drawing.Point(657, 416);
            this.DIACHI.Name = "DIACHI";
            this.DIACHI.Size = new System.Drawing.Size(97, 33);
            this.DIACHI.TabIndex = 23;
            this.DIACHI.Text = "Địa chỉ";
            // 
            // NGANHANG
            // 
            this.NGANHANG.AutoSize = true;
            this.NGANHANG.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NGANHANG.Location = new System.Drawing.Point(1072, 566);
            this.NGANHANG.Name = "NGANHANG";
            this.NGANHANG.Size = new System.Drawing.Size(147, 33);
            this.NGANHANG.TabIndex = 25;
            this.NGANHANG.Text = "Ngân Hàng";
            // 
            // SOTAIKHOAN
            // 
            this.SOTAIKHOAN.AutoSize = true;
            this.SOTAIKHOAN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SOTAIKHOAN.Location = new System.Drawing.Point(1072, 416);
            this.SOTAIKHOAN.Name = "SOTAIKHOAN";
            this.SOTAIKHOAN.Size = new System.Drawing.Size(162, 33);
            this.SOTAIKHOAN.TabIndex = 23;
            this.SOTAIKHOAN.Text = "Số tài khoản";
            // 
            // CHINHANHNGANHANG
            // 
            this.CHINHANHNGANHANG.AutoSize = true;
            this.CHINHANHNGANHANG.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CHINHANHNGANHANG.Location = new System.Drawing.Point(1072, 706);
            this.CHINHANHNGANHANG.Name = "CHINHANHNGANHANG";
            this.CHINHANHNGANHANG.Size = new System.Drawing.Size(267, 33);
            this.CHINHANHNGANHANG.TabIndex = 27;
            this.CHINHANHNGANHANG.Text = "Chi nhánh ngân hàng";
            // 
            // EMAIL
            // 
            this.EMAIL.AutoSize = true;
            this.EMAIL.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EMAIL.Location = new System.Drawing.Point(657, 706);
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.Size = new System.Drawing.Size(84, 33);
            this.EMAIL.TabIndex = 28;
            this.EMAIL.Text = "Email";
            // 
            // Luutttk
            // 
            this.Luutttk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.Luutttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Luutttk.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Luutttk.ForeColor = System.Drawing.Color.White;
            this.Luutttk.Location = new System.Drawing.Point(93, 874);
            this.Luutttk.Name = "Luutttk";
            this.Luutttk.Size = new System.Drawing.Size(350, 75);
            this.Luutttk.TabIndex = 31;
            this.Luutttk.Text = "Lưu thông tin tài khoản";
            this.Luutttk.UseVisualStyleBackColor = false;
            this.Luutttk.Click += new System.EventHandler(this.Luutttk_Click);
            // 
            // luuttct
            // 
            this.luuttct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.luuttct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.luuttct.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.luuttct.ForeColor = System.Drawing.Color.White;
            this.luuttct.Location = new System.Drawing.Point(893, 874);
            this.luuttct.Name = "luuttct";
            this.luuttct.Size = new System.Drawing.Size(350, 75);
            this.luuttct.TabIndex = 32;
            this.luuttct.Text = "Lưu thông tin chi tiết";
            this.luuttct.UseVisualStyleBackColor = false;
            this.luuttct.Click += new System.EventHandler(this.luuttct_Click);
            // 
            // cbbTDN
            // 
            this.cbbTDN.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDN.FormattingEnabled = true;
            this.cbbTDN.Location = new System.Drawing.Point(93, 283);
            this.cbbTDN.Name = "cbbTDN";
            this.cbbTDN.Size = new System.Drawing.Size(300, 31);
            this.cbbTDN.TabIndex = 45;
            // 
            // cbbMK
            // 
            this.cbbMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMK.FormattingEnabled = true;
            this.cbbMK.Location = new System.Drawing.Point(93, 420);
            this.cbbMK.Name = "cbbMK";
            this.cbbMK.Size = new System.Drawing.Size(300, 31);
            this.cbbMK.TabIndex = 46;
            // 
            // cbbXNMK
            // 
            this.cbbXNMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbXNMK.FormattingEnabled = true;
            this.cbbXNMK.Location = new System.Drawing.Point(93, 597);
            this.cbbXNMK.Name = "cbbXNMK";
            this.cbbXNMK.Size = new System.Drawing.Size(300, 31);
            this.cbbXNMK.TabIndex = 47;
            // 
            // cbbHT
            // 
            this.cbbHT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbHT.FormattingEnabled = true;
            this.cbbHT.Location = new System.Drawing.Point(657, 211);
            this.cbbHT.Name = "cbbHT";
            this.cbbHT.Size = new System.Drawing.Size(300, 31);
            this.cbbHT.TabIndex = 48;
            // 
            // cbbCMND
            // 
            this.cbbCMND.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbCMND.FormattingEnabled = true;
            this.cbbCMND.Location = new System.Drawing.Point(657, 346);
            this.cbbCMND.Name = "cbbCMND";
            this.cbbCMND.Size = new System.Drawing.Size(300, 31);
            this.cbbCMND.TabIndex = 49;
            // 
            // cbbDC
            // 
            this.cbbDC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbDC.FormattingEnabled = true;
            this.cbbDC.Location = new System.Drawing.Point(657, 479);
            this.cbbDC.Name = "cbbDC";
            this.cbbDC.Size = new System.Drawing.Size(300, 31);
            this.cbbDC.TabIndex = 50;
            // 
            // cbbSDT
            // 
            this.cbbSDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSDT.FormattingEnabled = true;
            this.cbbSDT.Location = new System.Drawing.Point(657, 629);
            this.cbbSDT.Name = "cbbSDT";
            this.cbbSDT.Size = new System.Drawing.Size(300, 31);
            this.cbbSDT.TabIndex = 51;
            // 
            // cbbE
            // 
            this.cbbE.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbE.FormattingEnabled = true;
            this.cbbE.Location = new System.Drawing.Point(657, 765);
            this.cbbE.Name = "cbbE";
            this.cbbE.Size = new System.Drawing.Size(300, 31);
            this.cbbE.TabIndex = 52;
            // 
            // cbbBSX
            // 
            this.cbbBSX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbBSX.FormattingEnabled = true;
            this.cbbBSX.Location = new System.Drawing.Point(1072, 211);
            this.cbbBSX.Name = "cbbBSX";
            this.cbbBSX.Size = new System.Drawing.Size(300, 31);
            this.cbbBSX.TabIndex = 53;
            // 
            // cbbKVHD
            // 
            this.cbbKVHD.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbKVHD.FormattingEnabled = true;
            this.cbbKVHD.Location = new System.Drawing.Point(1072, 346);
            this.cbbKVHD.Name = "cbbKVHD";
            this.cbbKVHD.Size = new System.Drawing.Size(300, 31);
            this.cbbKVHD.TabIndex = 54;
            // 
            // cbbSTK
            // 
            this.cbbSTK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbSTK.FormattingEnabled = true;
            this.cbbSTK.Location = new System.Drawing.Point(1072, 479);
            this.cbbSTK.Name = "cbbSTK";
            this.cbbSTK.Size = new System.Drawing.Size(300, 31);
            this.cbbSTK.TabIndex = 55;
            // 
            // cbbNH
            // 
            this.cbbNH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbNH.FormattingEnabled = true;
            this.cbbNH.Location = new System.Drawing.Point(1072, 626);
            this.cbbNH.Name = "cbbNH";
            this.cbbNH.Size = new System.Drawing.Size(300, 31);
            this.cbbNH.TabIndex = 56;
            // 
            // cbbCNNH
            // 
            this.cbbCNNH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbCNNH.FormattingEnabled = true;
            this.cbbCNNH.Location = new System.Drawing.Point(1072, 765);
            this.cbbCNNH.Name = "cbbCNNH";
            this.cbbCNNH.Size = new System.Drawing.Size(300, 31);
            this.cbbCNNH.TabIndex = 57;
            // 
            // TAIXE_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1584, 986);
            this.Controls.Add(this.cbbCNNH);
            this.Controls.Add(this.cbbNH);
            this.Controls.Add(this.cbbSTK);
            this.Controls.Add(this.cbbKVHD);
            this.Controls.Add(this.cbbBSX);
            this.Controls.Add(this.cbbE);
            this.Controls.Add(this.cbbSDT);
            this.Controls.Add(this.cbbDC);
            this.Controls.Add(this.cbbCMND);
            this.Controls.Add(this.cbbHT);
            this.Controls.Add(this.cbbXNMK);
            this.Controls.Add(this.cbbMK);
            this.Controls.Add(this.cbbTDN);
            this.Controls.Add(this.luuttct);
            this.Controls.Add(this.Luutttk);
            this.Controls.Add(this.CHINHANHNGANHANG);
            this.Controls.Add(this.EMAIL);
            this.Controls.Add(this.NGANHANG);
            this.Controls.Add(this.SDT);
            this.Controls.Add(this.SOTAIKHOAN);
            this.Controls.Add(this.CMND);
            this.Controls.Add(this.DIACHI);
            this.Controls.Add(this.BIENSOXE);
            this.Controls.Add(this.KHUVUC);
            this.Controls.Add(this.HOTEN);
            this.Controls.Add(this.XACNHANMATKHAU);
            this.Controls.Add(this.MATKHAU);
            this.Controls.Add(this.TENDANGNHAP);
            this.Controls.Add(this.TTTK);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "TAIXE_TK";
            this.Text = "TAIXE_TK";
            this.Load += new System.EventHandler(this.TAIXE_TK_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Label TTTK;
        private Label TENDANGNHAP;
        private Label MATKHAU;
        private Label XACNHANMATKHAU;
        private Label KHUVUC;
        private Label BIENSOXE;
        private Label HOTEN;
        private Label CMND;
        private Label SDT;
        private Label DIACHI;
        private Label NGANHANG;
        private Label SOTAIKHOAN;
        private Label CHINHANHNGANHANG;
        private Label EMAIL;
        private Button Luutttk;
        private Button luuttct;
        private ComboBox cbbTDN;
        private ComboBox cbbMK;
        private ComboBox cbbXNMK;
        private ComboBox cbbHT;
        private ComboBox cbbCMND;
        private ComboBox cbbDC;
        private ComboBox cbbSDT;
        private ComboBox cbbE;
        private ComboBox cbbBSX;
        private ComboBox cbbKVHD;
        private ComboBox cbbSTK;
        private ComboBox cbbNH;
        private ComboBox cbbCNNH;
    }
}