﻿namespace HQTCSDL
{
    partial class KHACHHANG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KHACHHANG));
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.button_Thoat = new System.Windows.Forms.Button();
            this.button_TK = new System.Windows.Forms.Button();
            this.button_DHCT = new System.Windows.Forms.Button();
            this.button_DH = new System.Windows.Forms.Button();
            this.panelLEFT = new System.Windows.Forms.Panel();
            this.AVATAR = new System.Windows.Forms.PictureBox();
            this.USER = new System.Windows.Forms.Button();
            this.button_DX = new System.Windows.Forms.Button();
            this.panel_body = new System.Windows.Forms.Panel();
            this.panelLEFT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 1033);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // button_Thoat
            // 
            this.button_Thoat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button_Thoat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_Thoat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button_Thoat.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_Thoat.FlatAppearance.BorderSize = 0;
            this.button_Thoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Thoat.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_Thoat.ForeColor = System.Drawing.Color.White;
            this.button_Thoat.Location = new System.Drawing.Point(0, 833);
            this.button_Thoat.Name = "button_Thoat";
            this.button_Thoat.Size = new System.Drawing.Size(300, 100);
            this.button_Thoat.TabIndex = 19;
            this.button_Thoat.Text = "Thoát";
            this.button_Thoat.UseVisualStyleBackColor = false;
            this.button_Thoat.Click += new System.EventHandler(this.button_Thoat_Click);
            // 
            // button_TK
            // 
            this.button_TK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button_TK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_TK.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_TK.FlatAppearance.BorderSize = 0;
            this.button_TK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_TK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_TK.ForeColor = System.Drawing.Color.White;
            this.button_TK.Location = new System.Drawing.Point(0, 535);
            this.button_TK.Name = "button_TK";
            this.button_TK.Size = new System.Drawing.Size(305, 100);
            this.button_TK.TabIndex = 17;
            this.button_TK.Text = "Tài Khoản";
            this.button_TK.UseVisualStyleBackColor = false;
            this.button_TK.Click += new System.EventHandler(this.button_TK_Click);
            // 
            // button_DHCT
            // 
            this.button_DHCT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button_DHCT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_DHCT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DHCT.FlatAppearance.BorderSize = 0;
            this.button_DHCT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DHCT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_DHCT.ForeColor = System.Drawing.Color.White;
            this.button_DHCT.Location = new System.Drawing.Point(-4, 439);
            this.button_DHCT.Name = "button_DHCT";
            this.button_DHCT.Size = new System.Drawing.Size(304, 100);
            this.button_DHCT.TabIndex = 16;
            this.button_DHCT.Text = "Quản lý đơn hàng";
            this.button_DHCT.UseVisualStyleBackColor = false;
            this.button_DHCT.Click += new System.EventHandler(this.buttonQLDH_Click);
            // 
            // button_DH
            // 
            this.button_DH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button_DH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_DH.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DH.FlatAppearance.BorderSize = 0;
            this.button_DH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_DH.ForeColor = System.Drawing.Color.White;
            this.button_DH.Location = new System.Drawing.Point(-5, 343);
            this.button_DH.Name = "button_DH";
            this.button_DH.Size = new System.Drawing.Size(305, 100);
            this.button_DH.TabIndex = 15;
            this.button_DH.Text = "Đặt Hàng";
            this.button_DH.UseVisualStyleBackColor = false;
            this.button_DH.Click += new System.EventHandler(this.button_DH_Click);
            // 
            // panelLEFT
            // 
            this.panelLEFT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelLEFT.Controls.Add(this.AVATAR);
            this.panelLEFT.Controls.Add(this.USER);
            this.panelLEFT.Controls.Add(this.button_Thoat);
            this.panelLEFT.Controls.Add(this.button_TK);
            this.panelLEFT.Controls.Add(this.button_DHCT);
            this.panelLEFT.Controls.Add(this.button_DH);
            this.panelLEFT.Controls.Add(this.button_DX);
            this.panelLEFT.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLEFT.Location = new System.Drawing.Point(4, 0);
            this.panelLEFT.Name = "panelLEFT";
            this.panelLEFT.Size = new System.Drawing.Size(300, 1033);
            this.panelLEFT.TabIndex = 23;
            // 
            // AVATAR
            // 
            this.AVATAR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AVATAR.Dock = System.Windows.Forms.DockStyle.Top;
            this.AVATAR.Image = ((System.Drawing.Image)(resources.GetObject("AVATAR.Image")));
            this.AVATAR.Location = new System.Drawing.Point(0, 0);
            this.AVATAR.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.AVATAR.Name = "AVATAR";
            this.AVATAR.Size = new System.Drawing.Size(300, 300);
            this.AVATAR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AVATAR.TabIndex = 20;
            this.AVATAR.TabStop = false;
            // 
            // USER
            // 
            this.USER.FlatAppearance.BorderSize = 0;
            this.USER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.USER.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.USER.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.USER.Location = new System.Drawing.Point(0, 300);
            this.USER.Name = "USER";
            this.USER.Size = new System.Drawing.Size(300, 50);
            this.USER.TabIndex = 12;
            this.USER.UseVisualStyleBackColor = true;
            // 
            // button_DX
            // 
            this.button_DX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button_DX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_DX.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button_DX.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_DX.FlatAppearance.BorderSize = 0;
            this.button_DX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_DX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_DX.ForeColor = System.Drawing.Color.White;
            this.button_DX.Location = new System.Drawing.Point(0, 933);
            this.button_DX.Name = "button_DX";
            this.button_DX.Size = new System.Drawing.Size(300, 100);
            this.button_DX.TabIndex = 11;
            this.button_DX.Text = "Đăng Xuất";
            this.button_DX.UseVisualStyleBackColor = false;
            this.button_DX.Click += new System.EventHandler(this.button_DX_Click);
            // 
            // panel_body
            // 
            this.panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_body.Location = new System.Drawing.Point(304, 0);
            this.panel_body.Name = "panel_body";
            this.panel_body.Size = new System.Drawing.Size(1598, 1033);
            this.panel_body.TabIndex = 24;
            // 
            // KHACHHANG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.panel_body);
            this.Controls.Add(this.panelLEFT);
            this.Controls.Add(this.splitter1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "KHACHHANG";
            this.Text = "KHÁCH HÀNG";
            this.Load += new System.EventHandler(this.KHACHHANG_Load);
            this.panelLEFT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AVATAR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Button button_DH;
        private Button button_TK;
        private Button button_DHCT;
        private Button button_Thoat;
        private Panel panelLEFT;
        private Button USER;
        private Button button_DX;
        private Panel panel_body;
        private PictureBox AVATAR;
    }
}