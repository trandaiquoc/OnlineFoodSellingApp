﻿namespace HQTCSDL
{
    partial class TAIXE_TN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.THEODOITHUNHAP = new System.Windows.Forms.Label();
            this.MADONHANG = new System.Windows.Forms.Label();
            this.TONGDANHTHU = new System.Windows.Forms.Label();
            this.THOIGIAN = new System.Windows.Forms.Label();
            this.PHIVANCHUYEN = new System.Windows.Forms.Label();
            this.cbbMDH = new System.Windows.Forms.ComboBox();
            this.cbbPVC = new System.Windows.Forms.ComboBox();
            this.cbbTG = new System.Windows.Forms.ComboBox();
            this.cbbTDT = new System.Windows.Forms.ComboBox();
            this.DATA = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 986);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // THEODOITHUNHAP
            // 
            this.THEODOITHUNHAP.Dock = System.Windows.Forms.DockStyle.Top;
            this.THEODOITHUNHAP.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.THEODOITHUNHAP.Location = new System.Drawing.Point(4, 0);
            this.THEODOITHUNHAP.Name = "THEODOITHUNHAP";
            this.THEODOITHUNHAP.Size = new System.Drawing.Size(1580, 100);
            this.THEODOITHUNHAP.TabIndex = 2;
            this.THEODOITHUNHAP.Text = "THEO DÕI THU NHẬP";
            this.THEODOITHUNHAP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MADONHANG
            // 
            this.MADONHANG.AutoSize = true;
            this.MADONHANG.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MADONHANG.Location = new System.Drawing.Point(201, 207);
            this.MADONHANG.Name = "MADONHANG";
            this.MADONHANG.Size = new System.Drawing.Size(172, 33);
            this.MADONHANG.TabIndex = 3;
            this.MADONHANG.Text = "Mã đơn hàng";
            // 
            // TONGDANHTHU
            // 
            this.TONGDANHTHU.AutoSize = true;
            this.TONGDANHTHU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TONGDANHTHU.Location = new System.Drawing.Point(201, 672);
            this.TONGDANHTHU.Name = "TONGDANHTHU";
            this.TONGDANHTHU.Size = new System.Drawing.Size(202, 33);
            this.TONGDANHTHU.TabIndex = 8;
            this.TONGDANHTHU.Text = "Tổng doanh thu";
            // 
            // THOIGIAN
            // 
            this.THOIGIAN.AutoSize = true;
            this.THOIGIAN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.THOIGIAN.Location = new System.Drawing.Point(201, 500);
            this.THOIGIAN.Name = "THOIGIAN";
            this.THOIGIAN.Size = new System.Drawing.Size(130, 33);
            this.THOIGIAN.TabIndex = 6;
            this.THOIGIAN.Text = "Thời gian";
            // 
            // PHIVANCHUYEN
            // 
            this.PHIVANCHUYEN.AutoSize = true;
            this.PHIVANCHUYEN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PHIVANCHUYEN.Location = new System.Drawing.Point(201, 357);
            this.PHIVANCHUYEN.Name = "PHIVANCHUYEN";
            this.PHIVANCHUYEN.Size = new System.Drawing.Size(193, 33);
            this.PHIVANCHUYEN.TabIndex = 17;
            this.PHIVANCHUYEN.Text = "Phí vận chuyển";
            // 
            // cbbMDH
            // 
            this.cbbMDH.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMDH.FormattingEnabled = true;
            this.cbbMDH.Location = new System.Drawing.Point(201, 260);
            this.cbbMDH.Name = "cbbMDH";
            this.cbbMDH.Size = new System.Drawing.Size(300, 31);
            this.cbbMDH.TabIndex = 46;
            // 
            // cbbPVC
            // 
            this.cbbPVC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbPVC.FormattingEnabled = true;
            this.cbbPVC.Location = new System.Drawing.Point(201, 415);
            this.cbbPVC.Name = "cbbPVC";
            this.cbbPVC.Size = new System.Drawing.Size(300, 31);
            this.cbbPVC.TabIndex = 47;
            // 
            // cbbTG
            // 
            this.cbbTG.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTG.FormattingEnabled = true;
            this.cbbTG.Location = new System.Drawing.Point(201, 562);
            this.cbbTG.Name = "cbbTG";
            this.cbbTG.Size = new System.Drawing.Size(300, 31);
            this.cbbTG.TabIndex = 48;
            // 
            // cbbTDT
            // 
            this.cbbTDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDT.FormattingEnabled = true;
            this.cbbTDT.Location = new System.Drawing.Point(201, 744);
            this.cbbTDT.Name = "cbbTDT";
            this.cbbTDT.Size = new System.Drawing.Size(300, 31);
            this.cbbTDT.TabIndex = 49;
            // 
            // DATA
            // 
            this.DATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DATA.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DATA.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DATA.DefaultCellStyle = dataGridViewCellStyle2;
            this.DATA.Location = new System.Drawing.Point(696, 207);
            this.DATA.Name = "DATA";
            this.DATA.RightToLeft = System.Windows.Forms.RightToLeft.No;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DATA.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DATA.RowHeadersWidth = 51;
            this.DATA.RowTemplate.Height = 29;
            this.DATA.Size = new System.Drawing.Size(581, 568);
            this.DATA.TabIndex = 50;
            this.DATA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_CellClick);
            // 
            // TAIXE_TN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1584, 986);
            this.Controls.Add(this.DATA);
            this.Controls.Add(this.cbbTDT);
            this.Controls.Add(this.cbbTG);
            this.Controls.Add(this.cbbPVC);
            this.Controls.Add(this.cbbMDH);
            this.Controls.Add(this.PHIVANCHUYEN);
            this.Controls.Add(this.TONGDANHTHU);
            this.Controls.Add(this.THOIGIAN);
            this.Controls.Add(this.MADONHANG);
            this.Controls.Add(this.THEODOITHUNHAP);
            this.Controls.Add(this.splitter1);
            this.Name = "TAIXE_TN";
            this.Text = "THUNHAPTAIXE";
            this.Load += new System.EventHandler(this.TAIXE_TN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private Label THEODOITHUNHAP;
        private Label MADONHANG;
        private Label TONGDANHTHU;
        private Label THOIGIAN;
        private Label PHIVANCHUYEN;
        private ComboBox cbbMDH;
        private ComboBox cbbPVC;
        private ComboBox cbbTG;
        private ComboBox cbbTDT;
        private DataGridView DATA;
    }
}