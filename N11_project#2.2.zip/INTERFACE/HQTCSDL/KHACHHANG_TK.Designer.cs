﻿namespace HQTCSDL
{
    partial class KHACHHANG_TK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TTTK = new System.Windows.Forms.Label();
            this.SDT = new System.Windows.Forms.ComboBox();
            this.DC = new System.Windows.Forms.ComboBox();
            this.cbbHT = new System.Windows.Forms.ComboBox();
            this.Email = new System.Windows.Forms.ComboBox();
            this.SOTAIKHOAN = new System.Windows.Forms.Label();
            this.DIACHI = new System.Windows.Forms.Label();
            this.Hoten = new System.Windows.Forms.Label();
            this.luuttct = new System.Windows.Forms.Button();
            this.Luutttk = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbXNMK = new System.Windows.Forms.ComboBox();
            this.cbbMK = new System.Windows.Forms.ComboBox();
            this.cbbTDN = new System.Windows.Forms.ComboBox();
            this.XACNHANMATKHAU = new System.Windows.Forms.Label();
            this.MATKHAU = new System.Windows.Forms.Label();
            this.TENDANGNHAP = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TTTK
            // 
            this.TTTK.Dock = System.Windows.Forms.DockStyle.Top;
            this.TTTK.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TTTK.Location = new System.Drawing.Point(0, 0);
            this.TTTK.Name = "TTTK";
            this.TTTK.Size = new System.Drawing.Size(1580, 114);
            this.TTTK.TabIndex = 3;
            this.TTTK.Text = "THÔNG TIN TÀI KHOẢN";
            this.TTTK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SDT
            // 
            this.SDT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SDT.FormattingEnabled = true;
            this.SDT.Location = new System.Drawing.Point(624, 319);
            this.SDT.Name = "SDT";
            this.SDT.Size = new System.Drawing.Size(300, 31);
            this.SDT.TabIndex = 77;
            // 
            // DC
            // 
            this.DC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DC.FormattingEnabled = true;
            this.DC.Location = new System.Drawing.Point(1090, 183);
            this.DC.Name = "DC";
            this.DC.Size = new System.Drawing.Size(300, 31);
            this.DC.TabIndex = 73;
            // 
            // cbbHT
            // 
            this.cbbHT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbHT.FormattingEnabled = true;
            this.cbbHT.Location = new System.Drawing.Point(624, 183);
            this.cbbHT.Name = "cbbHT";
            this.cbbHT.Size = new System.Drawing.Size(300, 31);
            this.cbbHT.TabIndex = 71;
            // 
            // Email
            // 
            this.Email.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Email.FormattingEnabled = true;
            this.Email.Location = new System.Drawing.Point(1090, 319);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(300, 31);
            this.Email.TabIndex = 69;
            // 
            // SOTAIKHOAN
            // 
            this.SOTAIKHOAN.AutoSize = true;
            this.SOTAIKHOAN.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SOTAIKHOAN.Location = new System.Drawing.Point(624, 268);
            this.SOTAIKHOAN.Name = "SOTAIKHOAN";
            this.SOTAIKHOAN.Size = new System.Drawing.Size(171, 33);
            this.SOTAIKHOAN.TabIndex = 65;
            this.SOTAIKHOAN.Text = "Số điện thoại";
            // 
            // DIACHI
            // 
            this.DIACHI.AutoSize = true;
            this.DIACHI.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DIACHI.Location = new System.Drawing.Point(1090, 128);
            this.DIACHI.Name = "DIACHI";
            this.DIACHI.Size = new System.Drawing.Size(97, 33);
            this.DIACHI.TabIndex = 64;
            this.DIACHI.Text = "Địa chỉ";
            // 
            // Hoten
            // 
            this.Hoten.AutoSize = true;
            this.Hoten.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Hoten.Location = new System.Drawing.Point(624, 128);
            this.Hoten.Name = "Hoten";
            this.Hoten.Size = new System.Drawing.Size(94, 33);
            this.Hoten.TabIndex = 60;
            this.Hoten.Text = "Họ tên";
            // 
            // luuttct
            // 
            this.luuttct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.luuttct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.luuttct.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.luuttct.ForeColor = System.Drawing.Color.White;
            this.luuttct.Location = new System.Drawing.Point(867, 608);
            this.luuttct.Name = "luuttct";
            this.luuttct.Size = new System.Drawing.Size(350, 75);
            this.luuttct.TabIndex = 80;
            this.luuttct.Text = "Lưu thông tin chi tiết";
            this.luuttct.UseVisualStyleBackColor = false;
            this.luuttct.Click += new System.EventHandler(this.luuttct_Click);
            // 
            // Luutttk
            // 
            this.Luutttk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.Luutttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Luutttk.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Luutttk.ForeColor = System.Drawing.Color.White;
            this.Luutttk.Location = new System.Drawing.Point(67, 608);
            this.Luutttk.Name = "Luutttk";
            this.Luutttk.Size = new System.Drawing.Size(350, 75);
            this.Luutttk.TabIndex = 79;
            this.Luutttk.Text = "Lưu thông tin tài khoản";
            this.Luutttk.UseVisualStyleBackColor = false;
            this.Luutttk.Click += new System.EventHandler(this.Luutttk_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1090, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 33);
            this.label1.TabIndex = 81;
            this.label1.Text = "Email";
            // 
            // cbbXNMK
            // 
            this.cbbXNMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbXNMK.FormattingEnabled = true;
            this.cbbXNMK.Location = new System.Drawing.Point(89, 456);
            this.cbbXNMK.Name = "cbbXNMK";
            this.cbbXNMK.Size = new System.Drawing.Size(300, 31);
            this.cbbXNMK.TabIndex = 87;
            // 
            // cbbMK
            // 
            this.cbbMK.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMK.FormattingEnabled = true;
            this.cbbMK.Location = new System.Drawing.Point(89, 316);
            this.cbbMK.Name = "cbbMK";
            this.cbbMK.Size = new System.Drawing.Size(300, 31);
            this.cbbMK.TabIndex = 86;
            // 
            // cbbTDN
            // 
            this.cbbTDN.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTDN.FormattingEnabled = true;
            this.cbbTDN.Location = new System.Drawing.Point(89, 189);
            this.cbbTDN.Name = "cbbTDN";
            this.cbbTDN.Size = new System.Drawing.Size(300, 31);
            this.cbbTDN.TabIndex = 85;
            // 
            // XACNHANMATKHAU
            // 
            this.XACNHANMATKHAU.AutoSize = true;
            this.XACNHANMATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.XACNHANMATKHAU.Location = new System.Drawing.Point(89, 402);
            this.XACNHANMATKHAU.Name = "XACNHANMATKHAU";
            this.XACNHANMATKHAU.Size = new System.Drawing.Size(241, 33);
            this.XACNHANMATKHAU.TabIndex = 84;
            this.XACNHANMATKHAU.Text = "Xác nhận mật khẩu";
            // 
            // MATKHAU
            // 
            this.MATKHAU.AutoSize = true;
            this.MATKHAU.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MATKHAU.Location = new System.Drawing.Point(89, 259);
            this.MATKHAU.Name = "MATKHAU";
            this.MATKHAU.Size = new System.Drawing.Size(126, 33);
            this.MATKHAU.TabIndex = 83;
            this.MATKHAU.Text = "Mật khẩu";
            // 
            // TENDANGNHAP
            // 
            this.TENDANGNHAP.AutoSize = true;
            this.TENDANGNHAP.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TENDANGNHAP.Location = new System.Drawing.Point(89, 128);
            this.TENDANGNHAP.Name = "TENDANGNHAP";
            this.TENDANGNHAP.Size = new System.Drawing.Size(193, 33);
            this.TENDANGNHAP.TabIndex = 82;
            this.TENDANGNHAP.Text = "Tên đăng nhập";
            // 
            // KHACHHANG_TK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1580, 986);
            this.Controls.Add(this.cbbXNMK);
            this.Controls.Add(this.cbbMK);
            this.Controls.Add(this.cbbTDN);
            this.Controls.Add(this.XACNHANMATKHAU);
            this.Controls.Add(this.MATKHAU);
            this.Controls.Add(this.TENDANGNHAP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.luuttct);
            this.Controls.Add(this.Luutttk);
            this.Controls.Add(this.SDT);
            this.Controls.Add(this.DC);
            this.Controls.Add(this.cbbHT);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.SOTAIKHOAN);
            this.Controls.Add(this.DIACHI);
            this.Controls.Add(this.Hoten);
            this.Controls.Add(this.TTTK);
            this.Name = "KHACHHANG_TK";
            this.Text = "KHACHHANG_TK";
            this.Load += new System.EventHandler(this.KHACHHANG_TK_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label TTTK;
        private ComboBox SDT;
        private ComboBox DC;
        private ComboBox cbbHT;
        private ComboBox Email;
        private Label SOTAIKHOAN;
        private Label DIACHI;
        private Label Hoten;
        private Button luuttct;
        private Button Luutttk;
        private Label label1;
        private ComboBox cbbXNMK;
        private ComboBox cbbMK;
        private ComboBox cbbTDN;
        private Label XACNHANMATKHAU;
        private Label MATKHAU;
        private Label TENDANGNHAP;
    }
}