﻿namespace HQTCSDL
{
    partial class ADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN));
            this.panel1 = new System.Windows.Forms.Panel();
            this.USER = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.THOAT = new System.Windows.Forms.Button();
            this.buttonDH = new System.Windows.Forms.Button();
            this.buttonTK = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_body = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.USER);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.THOAT);
            this.panel1.Controls.Add(this.buttonDH);
            this.panel1.Controls.Add(this.buttonTK);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 1033);
            this.panel1.TabIndex = 0;
            // 
            // USER
            // 
            this.USER.FlatAppearance.BorderSize = 0;
            this.USER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.USER.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.USER.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.USER.Location = new System.Drawing.Point(0, 300);
            this.USER.Name = "USER";
            this.USER.Size = new System.Drawing.Size(300, 50);
            this.USER.TabIndex = 13;
            this.USER.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(0, 833);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(300, 100);
            this.button6.TabIndex = 11;
            this.button6.Text = "Đăng Xuất";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // THOAT
            // 
            this.THOAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.THOAT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.THOAT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.THOAT.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.THOAT.FlatAppearance.BorderSize = 0;
            this.THOAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.THOAT.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.THOAT.ForeColor = System.Drawing.Color.White;
            this.THOAT.Location = new System.Drawing.Point(0, 933);
            this.THOAT.Name = "THOAT";
            this.THOAT.Size = new System.Drawing.Size(300, 100);
            this.THOAT.TabIndex = 10;
            this.THOAT.Text = "Thoát";
            this.THOAT.UseVisualStyleBackColor = false;
            this.THOAT.Click += new System.EventHandler(this.button5_Click);
            // 
            // buttonDH
            // 
            this.buttonDH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonDH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonDH.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDH.FlatAppearance.BorderSize = 0;
            this.buttonDH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDH.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDH.ForeColor = System.Drawing.Color.White;
            this.buttonDH.Location = new System.Drawing.Point(0, 449);
            this.buttonDH.Name = "buttonDH";
            this.buttonDH.Size = new System.Drawing.Size(300, 100);
            this.buttonDH.TabIndex = 8;
            this.buttonDH.Text = "Quản Lý Tài Khoản";
            this.buttonDH.UseVisualStyleBackColor = false;
            this.buttonDH.Click += new System.EventHandler(this.buttonDH_Click);
            // 
            // buttonTK
            // 
            this.buttonTK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonTK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonTK.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonTK.FlatAppearance.BorderSize = 0;
            this.buttonTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTK.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonTK.ForeColor = System.Drawing.Color.White;
            this.buttonTK.Location = new System.Drawing.Point(0, 350);
            this.buttonTK.Name = "buttonTK";
            this.buttonTK.Size = new System.Drawing.Size(300, 100);
            this.buttonTK.TabIndex = 7;
            this.buttonTK.Text = "Tài Khoản";
            this.buttonTK.UseVisualStyleBackColor = false;
            this.buttonTK.Click += new System.EventHandler(this.buttonTK_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(300, 300);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // panel_body
            // 
            this.panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_body.Location = new System.Drawing.Point(300, 0);
            this.panel_body.Name = "panel_body";
            this.panel_body.Size = new System.Drawing.Size(1602, 1033);
            this.panel_body.TabIndex = 0;
            // 
            // ADMIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.panel_body);
            this.Controls.Add(this.panel1);
            this.Name = "ADMIN";
            this.Text = "TAIXE";
            this.Load += new System.EventHandler(this.ADMIN_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel_body;
        private PictureBox pictureBox2;
        private Button button6;
        private Button THOAT;
        private Button buttonDH;
        private Button buttonTK;
        private Button USER;
    }
}