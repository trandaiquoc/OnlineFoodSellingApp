﻿namespace HQTCSDL
{
    partial class DOITAC_SP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.cbbTC = new System.Windows.Forms.ComboBox();
            this.cbbMT = new System.Windows.Forms.ComboBox();
            this.cbbT = new System.Windows.Forms.ComboBox();
            this.TC = new System.Windows.Forms.Label();
            this.MT = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbG = new System.Windows.Forms.ComboBox();
            this.cbbTT = new System.Windows.Forms.ComboBox();
            this.cbbMM = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.DATA = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1602, 100);
            this.label3.TabIndex = 93;
            this.label3.Text = "SẢN PHẨM";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonS
            // 
            this.buttonS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonS.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonS.ForeColor = System.Drawing.Color.White;
            this.buttonS.Location = new System.Drawing.Point(1025, 395);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(300, 75);
            this.buttonS.TabIndex = 116;
            this.buttonS.Text = "Sửa";
            this.buttonS.UseVisualStyleBackColor = false;
            this.buttonS.Click += new System.EventHandler(this.buttonS_Click);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonX.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonX.ForeColor = System.Drawing.Color.White;
            this.buttonX.Location = new System.Drawing.Point(1025, 284);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(300, 75);
            this.buttonX.TabIndex = 115;
            this.buttonX.Text = "Xoá";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonT
            // 
            this.buttonT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(100)))), ((int)(((byte)(210)))));
            this.buttonT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonT.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonT.ForeColor = System.Drawing.Color.White;
            this.buttonT.Location = new System.Drawing.Point(1025, 173);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(300, 75);
            this.buttonT.TabIndex = 114;
            this.buttonT.Text = "Thêm";
            this.buttonT.UseVisualStyleBackColor = false;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // cbbTC
            // 
            this.cbbTC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbTC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTC.FormattingEnabled = true;
            this.cbbTC.Location = new System.Drawing.Point(528, 431);
            this.cbbTC.Name = "cbbTC";
            this.cbbTC.Size = new System.Drawing.Size(250, 31);
            this.cbbTC.TabIndex = 113;
            // 
            // cbbMT
            // 
            this.cbbMT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMT.FormattingEnabled = true;
            this.cbbMT.Items.AddRange(new object[] {
            "Tái Ký"});
            this.cbbMT.Location = new System.Drawing.Point(528, 320);
            this.cbbMT.Name = "cbbMT";
            this.cbbMT.Size = new System.Drawing.Size(250, 31);
            this.cbbMT.TabIndex = 112;
            // 
            // cbbT
            // 
            this.cbbT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbT.FormattingEnabled = true;
            this.cbbT.Location = new System.Drawing.Point(528, 197);
            this.cbbT.Name = "cbbT";
            this.cbbT.Size = new System.Drawing.Size(250, 31);
            this.cbbT.TabIndex = 111;
            // 
            // TC
            // 
            this.TC.AutoSize = true;
            this.TC.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TC.Location = new System.Drawing.Point(528, 395);
            this.TC.Name = "TC";
            this.TC.Size = new System.Drawing.Size(91, 23);
            this.TC.TabIndex = 110;
            this.TC.Text = "Tuỳ Chọn";
            // 
            // MT
            // 
            this.MT.AutoSize = true;
            this.MT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MT.Location = new System.Drawing.Point(528, 284);
            this.MT.Name = "MT";
            this.MT.Size = new System.Drawing.Size(74, 23);
            this.MT.TabIndex = 109;
            this.MT.Text = "Miêu tả";
            this.MT.UseMnemonic = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(528, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 23);
            this.label4.TabIndex = 108;
            this.label4.Text = "Tên món";
            // 
            // cbbG
            // 
            this.cbbG.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbG.FormattingEnabled = true;
            this.cbbG.Location = new System.Drawing.Point(105, 431);
            this.cbbG.Name = "cbbG";
            this.cbbG.Size = new System.Drawing.Size(250, 31);
            this.cbbG.TabIndex = 107;
            // 
            // cbbTT
            // 
            this.cbbTT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbTT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbTT.FormattingEnabled = true;
            this.cbbTT.Items.AddRange(new object[] {
            "Có bán",
            "Hết Hàng",
            "Tạm Ngưng"});
            this.cbbTT.Location = new System.Drawing.Point(105, 320);
            this.cbbTT.Name = "cbbTT";
            this.cbbTT.Size = new System.Drawing.Size(250, 31);
            this.cbbTT.TabIndex = 106;
            // 
            // cbbMM
            // 
            this.cbbMM.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbbMM.FormattingEnabled = true;
            this.cbbMM.Location = new System.Drawing.Point(105, 197);
            this.cbbMM.Name = "cbbMM";
            this.cbbMM.Size = new System.Drawing.Size(250, 31);
            this.cbbMM.TabIndex = 105;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(105, 395);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 23);
            this.label7.TabIndex = 104;
            this.label7.Text = "Giá";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(105, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 23);
            this.label6.TabIndex = 103;
            this.label6.Text = "Tình Trạng";
            this.label6.UseMnemonic = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(105, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 23);
            this.label8.TabIndex = 102;
            this.label8.Text = "Mã món";
            // 
            // DATA
            // 
            this.DATA.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DATA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.DATA.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DATA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DATA.Location = new System.Drawing.Point(0, 627);
            this.DATA.Name = "DATA";
            this.DATA.RowHeadersWidth = 51;
            this.DATA.RowTemplate.Height = 29;
            this.DATA.Size = new System.Drawing.Size(1602, 359);
            this.DATA.TabIndex = 117;
            this.DATA.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DATA_CellClick);
            // 
            // DOITAC_SP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1602, 986);
            this.Controls.Add(this.DATA);
            this.Controls.Add(this.buttonS);
            this.Controls.Add(this.buttonX);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.cbbTC);
            this.Controls.Add(this.cbbMT);
            this.Controls.Add(this.cbbT);
            this.Controls.Add(this.TC);
            this.Controls.Add(this.MT);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbbG);
            this.Controls.Add(this.cbbTT);
            this.Controls.Add(this.cbbMM);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Name = "DOITAC_SP";
            this.Text = "DOITAC_SP";
            this.Load += new System.EventHandler(this.DOITAC_SP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label3;
        private Button buttonS;
        private Button buttonX;
        private Button buttonT;
        private ComboBox cbbTC;
        private ComboBox cbbMT;
        private ComboBox cbbT;
        private Label TC;
        private Label MT;
        private Label label4;
        private ComboBox cbbG;
        private ComboBox cbbTT;
        private ComboBox cbbMM;
        private Label label7;
        private Label label6;
        private Label label8;
        private DataGridView DATA;
    }
}